<?php
class User extends AppModel
{
     public $validationDomain = 'validation';
  //public $useTable="employees";
}
?>