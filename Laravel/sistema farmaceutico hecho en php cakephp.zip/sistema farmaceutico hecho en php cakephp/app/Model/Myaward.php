<?php
class Myaward extends AppModel
{
    public $validationDomain = 'validation';
    public $useTable='awards';
    public $belongsTo=array('Employee');
    public $actsAs = array('search-master.Searchable');
    public $filterArgs = array('keyword' => array('type' => 'like','field'=>'Myaward.name'));
}
?>