<?php
class Emailverification extends AppModel
{
  public $validationDomain = 'validation';
  public $useTable="employees";  
}
?>