<?php
class Dashboard extends AppModel
{
     public $validationDomain = 'validation';
    public $useTable="employees";
    public $belongsTo=array('Department','DepartmentsDesignation');
}
