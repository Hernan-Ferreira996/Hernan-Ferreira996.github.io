<?php
/**
 * Application level View Helper
 *
 * This file is application-wide helper file. You can put all
 * application-wide helper-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.View.Helper
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Helper', 'View');

/**
 * Application helper
 *
 * Add your application-wide methods in the class below, your helpers
 * will inherit them.
 *
 * @package       app.View.Helper
 */
class FunctionHelper extends Helper {
    public function secondsToWords($seconds,$textShow="Unlimited")
    {
        $ret = "";
        if($seconds>0)
        {
            /*** get the hours ***/
            $hours = intval(intval($seconds) / 3600);
            if($hours > 0)
            {
                $ret .= "$hours Hours ";
            }
            /*** get the minutes ***/
            $minutes = bcmod((intval($seconds) / 60),60);
            if($hours > 0 || $minutes > 0)
            {
                $ret .= "$minutes Mins. ";
            }
            if(strlen($ret)==0)
            {
                $ret .= "$seconds Sec ";
            }
        }
        else
        {
            $ret=$textShow;
        }
        return $ret;
    }
    public function showMemberName($post,$count=3)
    {
        $name="";
        if($count==3)
        $name=implode(" ",array($post['first_name'],$post['middle_name'],$post['last_name']));
        elseif($count==2)
        $name=implode(" ",array($post['first_name'],$post['last_name']));
        else
        $name=$post['first_name'];
        return$name;
    }
    public function showGroupName($gropArr,$string=" | ")
    {
        $groupNameArr=array();
        foreach($gropArr as $groupName)
        {
            $groupNameArr[]=$groupName['name'];
        }
        unset($groupName);
        $showGroup= implode($string,$groupNameArr);
        unset($groupNameArr);
        return h($showGroup);
    }
    public function cashout($bill_num)
    {
       $Managereturnmedicine=ClassRegistry::init('Managereturnmedicine');
       $sql="select SUM(total) as total from managereturnmedicines where bill_num='$bill_num'";
       $cashArr=$Managereturnmedicine->query($sql);
       return$cashArr[0][0]['total'];
    }
    public function checkbill($bill_num)
    {
       $Soldbilling=ClassRegistry::init('Soldbilling');
       $soldArr=$Soldbilling->find('all',array('fields'=>array(''),
                                               'conditions'=>array('Soldbilling.bill_num'=>$bill_num)));
       return$soldArr;
    }
    public function checkid($bill_num)
    {
       $Soldbilling=ClassRegistry::init('Soldbilling');
       $soldArr=$Soldbilling->find('first',array('fields'=>array('Soldbilling.id'),
                                               'conditions'=>array('Soldbilling.bill_num'=>$bill_num)));
       return$soldArr['Soldbilling']['id'];
    }
    public function finaltotal($bill_num)
    {
       $Soldbilling=ClassRegistry::init('Soldbilling');
       $soldArr=$Soldbilling->find('first',array('fields'=>array('Soldbilling.finaltotal'),
                                               'conditions'=>array('Soldbilling.bill_num'=>$bill_num)));
       return$soldArr['Soldbilling']['finaltotal'];
    }
    public function attandance($empId,$date)
    {
       $Attendance=ClassRegistry::init('Attendance');
       $attendanceArr=$Attendance->find('first',array('conditions'=>array('employee_id'=>$empId,'date'=>$date)));
       return$attendanceArr;
    }
    public function attandanceCount($empId,$leaveId)
    {  
       $Application=ClassRegistry::init('Application');
       $count=$Application->find('count',array('conditions'=>array('employee_id'=>$empId,'leavetype_id'=>$leaveId,'status'=>'Approved')));
       return$count;
    }
   public function attandanceAbsent($empId,$currentDateTime)
    {
       $date=null; 
       $Attendance=ClassRegistry::init('Attendance');
       $attendanceArr=$Attendance->find('first',array('fields'=>array('Attendance.date'),'conditions'=>array('Attendance.employee_id'=>$empId,'Attendance.status'=>0),
                                                      'order'=>array('Attendance.date'=>'desc')));
       if($attendanceArr)
       $date=$this->remainingTime($attendanceArr['Attendance']['date'],$currentDateTime);
       return$date;
    }
    function remainingTime($createdTime,$currentDateTime)
    {
        $str = strtotime($createdTime);
        $today = strtotime($currentDateTime);
        $at=__('\a\t');
        $yest=__('\Y\e\s\t\e\r\d\a\y');

        // It returns the time difference in Seconds...
        $timeDiffernce = $today-$str;

        // To Calculate the time difference in Years...
        $years = 60*60*24*365;

        // To Calculate the time difference in Months...
        $months = 60*60*24*30;

        // To Calculate the time difference in Weeks...
        $weeks = 60*60*24*7;

        // To Calculate the time difference in Days...
        $days = 60*60*24;

        // To Calculate the time difference in Hours...
        $hours = 60*60;

        // To Calculate the time difference in Minutes...
        $minutes = 60;

        if(intval(($timeDiffernce/$years)) > 1)
        {
            return __('%s years',intval(($timeDiffernce/$years)));
        }elseif(intval(($timeDiffernce/$years)) > 0)
        {
            return __('%s year',intval(($timeDiffernce/$years)));
        }elseif(intval(($timeDiffernce/$months)) > 1)
        {
            return __('%s months',intval(($timeDiffernce/$months)));
        }elseif(intval(($timeDiffernce/$months)) > 0)
        {
            return __('%s month',intval(($timeDiffernce/$months)));
        }elseif(intval(($timeDiffernce/$weeks)) > 1)
        {
            return __('%s weeks',intval(($timeDiffernce/$weeks)));
        }elseif(intval(($timeDiffernce/$weeks)) > 0)
        {
            return __('%s week',intval(($timeDiffernce/$weeks)));
        }elseif(intval(($timeDiffernce/$days)) > 1)
        {
            //return date('F d '.$at.' H:ia',$str);
            return __('%s days',intval(($timeDiffernce/$days)));
        }elseif (intval(($timeDiffernce/$days)) > 0) 
        {            
            //return date($yest.' '.$at.' H:ia',$str);
            return __('%s day',intval(($timeDiffernce/$days)));
        }else if (intval(($timeDiffernce/$hours)) > 1) 
        {
            return __('%s hours',intval(($timeDiffernce/$hours)));
        }else if (intval(($timeDiffernce/$hours)) > 0) 
        {
            return __('%s hour',intval(($timeDiffernce/$hours)));
        }else if (intval(($timeDiffernce/$minutes)) > 1) 
        {
            return __('%s minutes',intval(($timeDiffernce/$minutes)));
        }else if (intval(($timeDiffernce/$minutes)) > 0) 
        {
            return __('%s minute',intval(($timeDiffernce/$minutes)));
        }else if (intval(($timeDiffernce)) > 1) 
        {
            return __('%s seconds',intval(($timeDiffernce)));
        }else
        {
            return __('Just Now');
        }
    }
}
