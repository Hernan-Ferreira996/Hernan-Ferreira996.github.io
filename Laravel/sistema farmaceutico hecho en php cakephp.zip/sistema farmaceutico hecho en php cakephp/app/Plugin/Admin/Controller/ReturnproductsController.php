<?php
class ReturnproductsController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Returnproduct.id'=>'desc'));
    public function index()
    {
        $cond=array('qty >'=>0);
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
         $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond[]=array('Returnproduct.user_id'=>$userId);
        }
        $this->Paginator->settings['conditions'] = array($this->Returnproduct->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
    public function deleteall()
    {
        $this->loadModel('Returnproductsupplier');
     if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            if ($this->request->is('post'))
            {
                if(isset($this->request->data['selectAll']) && strlen($this->request->data['selectAll'])>0)
                {
                  unset($this->request->data['selectAll']);  
                }
               
                 

                foreach($this->data as $key => $value)
                {
                    if($value['Returnproduct']['id']!=0){
                    $actualQty=$this->Returnproduct->findById($value['Returnproduct']['id']);
                    echo$qty=$value['Returnproduct']['qty'];
                    $value['Returnproduct']['qty']=$actualQty['Returnproduct']['qty']-$qty;
                    $this->Returnproduct->save($value);
                    $product=$this->Returnproduct->findById($value['Returnproduct']['id']);
                    $price=$qty*$product['Returnproduct']['price_one_piece'];
                    $record=array('price_one_piece'=>$product['Returnproduct']['price_one_piece'],'expiry'=>$product['Returnproduct']['expiry_date'],'supplier_id'=>$product['Returnproduct']['supplier_id'],'user_id'=>$this->adminValue['User']['id'],'invoice_no'=>$product['Returnproduct']['invoice_no'],'medicine_name'=>$product['Returnproduct']['name'],'qty'=>$qty,'price'=>$price);
                    $this->Returnproductsupplier->create();
                    $this->Returnproductsupplier->save($record);
                    }
                }
                $this->Session->setFlash(__('Product Return Successfully !'),'flash',array('alert'=>'success'));
            }        
           $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
}
?>