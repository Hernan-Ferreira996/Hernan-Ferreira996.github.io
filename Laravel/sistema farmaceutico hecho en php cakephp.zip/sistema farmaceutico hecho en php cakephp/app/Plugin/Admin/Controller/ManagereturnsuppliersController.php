<?php
class ManagereturnsuppliersController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg','PhpExcel.PhpExcel');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Managereturnsupplier.id'=>'desc'));
    public function index()
    {
        $cond=array();
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
         $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Managereturnsupplier.user_id'=>$userId);
        }
        $this->Paginator->settings['conditions'] = array($this->Managereturnsupplier->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
    public function printsupplierbill($invoiceNo=null)
    {
	try{
	    $this->layout=null;
            if (!$invoiceNo) {
            throw new NotFoundException(__('Invalid post'));
            }
	    $post=$this->Managereturnsupplier->find('all',array('conditions'=>array('Managereturnsupplier.invoice_no'=>$invoiceNo)));
            if (!$post) {
            throw new NotFoundException(__('Invalid post'));
            }
            
                $this->set('posts',$post);
        }
	catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage(),'flash',array('alert'=>'danger'));
        }
    }    
    public function deleteall()
    {
     if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            if ($this->request->is('post'))
            {
                foreach($this->data['Managereturnsupplier']['id'] as $key => $value)
                {
                    $this->Managereturnsupplier->delete($value);
                }
                $this->Session->setFlash(__('Return Supplier has been deleted!'),'flash',array('alert'=>'danger'));
            }        
            $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
    public function export()
    {
	$this->layout=null;
        $this->autoRender=false;
        try
        {
            $data=$this->exportData();
            $this->PhpExcel->createWorksheet();
            $this->PhpExcel->addTableRow($data);
            $this->PhpExcel->output('ManageReturnSupplier',$this->siteName,'ReturnSupplier.xls','Excel2007');
        }
        catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage(),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }    
    private function exportData()
    {
	$cond=array();
        $siteName=$this->siteOrganization;
	$userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Managereturnsupplier.user_id'=>$userId);
        }
        $post=$this->Managereturnsupplier->find('all',array('conditions'=>$cond));
        $data=$this->showProductData($post);
        return $data;
    }
    private function showProductData($post)
    {
        
        $showData=array();
        if($post)
        {
       
            $showData=array(array(__('Invoice No'),__('Supplier Mobile'),__('Medicine Name'),__('Quantity'),__('Price Per Piece'),__('Price'),__('Expiry Date'),__('Return Date')));
            
            foreach($post as $rank=>$value)
            {
                   if($value['Managereturnsupplier']['expiry']){$expiryDate=CakeTime::format('d-M-Y',$value['Managereturnsupplier']['expiry']);}else{$expiryDate=null;}
                   if($value['Managereturnsupplier']['created']){$returnDate=CakeTime::format('d-M-Y',$value['Managereturnsupplier']['created']);}else{$returnDate=null;}
                   $showData[]=array('Invoice No'=>$value['Managereturnsupplier']['invoice_no'],'Supplier Mobile'=>$value['Supplier']['mobile'],
                                  'Medicine Name'=>$value['Managereturnsupplier']['medicine_name'],'Quantity'=>$value['Managereturnsupplier']['qty'],
                                  'Price Per Piece'=>number_format($value['Managereturnsupplier']['price_one_piece'],2),
                                  'Price'=>number_format($value['Managereturnsupplier']['price'],2),
                                  'Expiry Date'=>$expiryDate,'Return Date'=>$returnDate);
            }
            
        }
        else
        {
          $showData=array(array(__('No Record Found')));
         
        }
        return$showData;
    }
    public function download()
    {
        $this->viewClass = 'Media';
        $params = array(
            'id'        => 'sample-Product.xls',
            'name'      => 'SampleProduct',
            'download'  => true,
            'extension' => 'xls',
            'mimeType'  => array('xls' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
            'path'      => APP . 'tmp' . DS.'download'.DS
        );
        $this->set($params);
    }
}
?>