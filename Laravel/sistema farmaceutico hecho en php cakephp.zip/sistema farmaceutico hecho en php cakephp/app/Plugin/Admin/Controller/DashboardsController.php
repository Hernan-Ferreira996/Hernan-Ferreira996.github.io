<?php
App::uses('CakeTime', 'Utility');
App::uses('CakeNumber', 'Utility');
class DashboardsController extends AdminAppController
{   public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg','PhpExcel.PhpExcel');
    public $presetVars = true;
    
    public function index()
    {
        
        $contactArr=array();$userId=$this->adminValue['User']['id'];
        $colorArr=array(array('color'=>'rgba(93,165,218,0.7)','fillColor'=>'rgba(93,165,218,0.2)','highlight'=>'rgba(93,165,218,1)'),
                        array('color'=>'rgba(250,164,58,0.7)','fillColor'=>'rgba(250,164,58,0.2)','highlight'=>'rgba(250,164,58,1'),
                        array('color'=>'rgba(96,189,104,0.7)','fillColor'=>'rgba(96,189,104,0.2)','highlight'=>'rgba(96,189,104,1)'),
                        array('color'=>'rgba(241,124,176,0.7)','fillColor'=>'rgba(241,124,176,0.2)','highlight'=>'rgba(241,124,176,1)'),
                        array('color'=>'rgba(178,175,47,0.7)','fillColor'=>'rgba(178,175,47,0.2)','highlight'=>'rgba(178,175,47,1)'),
                        array('color'=>'rgba(178,118,178,0.7)','fillColor'=>'rgba(178,118,178,0.2)','highlight'=>'rgba(178,118,178,1)'),
                        array('color'=>'rgba(77,77,77,0.7)','fillColor'=>'rgba(77,77,77,0.2)','highlight'=>'rgba(77,77,77,1)'),
                        array('color'=>'rgba(222,207,63,0.7)','fillColor'=>'rgba(222,207,63,0.2)','highlight'=>'rgba(222,207,63,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(139,20,39,0.7)','fillColor'=>'rgba(139,20,39,0.2)','highlight'=>'rgba(139,20,39,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)'),
                        array('color'=>'rgba(241,88,84,0.7)','fillColor'=>'rgba(241,88,84,0.2)','highlight'=>'rgba(241,88,84,1)')
                        );
        $this->set('colorArr',$colorArr);
	/* Sale Report */
        $this->loadModel('Soldbilling');
        $this->set('Expense',$this->Soldbilling->find('all'));
        for ($i = 0; $i < 12; ++$i)
        {
            $year=CakeTime::format("-$i months",'%Y',$this->siteTimezone);
            $month=CakeTime::format("-$i months",'%m',$this->siteTimezone);
            $monthName=CakeTime::format("-$i months",'%b %Y',$this->siteTimezone);
            $this->Soldbilling->virtualFields=array('total'=>'SUM(Soldbilling.finaltotal)');
	    if($userId!=1){
	     $recordArr=$this->Soldbilling->find('first',array('fields'=>array('total'),'conditions'=>array('MONTH(Soldbilling.created)'=>$month,'YEAR(Soldbilling.created)'=>$year,'user_id'=>$this->adminValue['User']['id'])));
           }
	    else{
	    $recordArr=$this->Soldbilling->find('first',array('fields'=>array('total'),'conditions'=>array('MONTH(Soldbilling.created)'=>$month,'YEAR(Soldbilling.created)'=>$year)));
            }
	    
            $this->Soldbilling->virtualFields=array();
            $record=$recordArr['Soldbilling']['total'];
            
            $expenseArr[]=array('index'=>$monthName,'value'=>round($record,2));
        }
        
        $this->set('expenseArr',array_reverse($expenseArr));
       /* end sale report */
       /* Purchase Report */
        $this->loadModel('Purchase');
        for ($i = 0; $i < 12; ++$i)
        {
            $year1=CakeTime::format("-$i months",'%Y',$this->siteTimezone);
            $month1=CakeTime::format("-$i months",'%m',$this->siteTimezone);
            $monthName1=CakeTime::format("-$i months",'%b %Y',$this->siteTimezone);
            $this->Purchase->virtualFields=array('total'=>'SUM(Purchase.price)');
	    if($userId!=1){
	     $recordArr1=$this->Purchase->find('first',array('fields'=>array('total'),'conditions'=>array('MONTH(Purchase.created)'=>$month1,'YEAR(Purchase.created)'=>$year1,'user_id'=>$this->adminValue['User']['id'])));
           }
	    else{
	    $recordArr1=$this->Purchase->find('first',array('fields'=>array('total'),'conditions'=>array('MONTH(Purchase.created)'=>$month1,'YEAR(Purchase.created)'=>$year1)));
            }
	    
            $this->Purchase->virtualFields=array();
            $record1=$recordArr1['Purchase']['total'];
            
            $expenseArr1[]=array('index'=>$monthName1,'value'=>round($record1,2));
        }
        
        $this->set('expenseArr1',array_reverse($expenseArr1));
       /* end Purchase report */
        $currentDateTime=CakeTime::format('Y-m-d',CakeTime::convert(time(),$this->siteTimezone));
        $currentDay=CakeTime::format('d',$this->currentDate);
        $currentMonth=CakeTime::format('m',$this->currentDate);
        $currentYear=CakeTime::format('Y',$this->currentDate);
        $this->set('currentDateTime',$this->currentDateTime);
	
	
	
	$this->loadModel('Product');
        if($userId!=1){
	    $productCount=$this->Product->find('count',array('conditions'=>array('Product.user_id'=>$this->adminValue['User']['id'])));
        }
	else{
	   $productCount=$this->Product->find('count');
	}
        $this->set('productCount',$productCount);
        
        $this->loadModel('Supplier');
	
	
	if($userId!=1){
	    $supplierCount=$this->Supplier->find('count',array('conditions'=>array('Supplier.user_id'=>$this->adminValue['User']['id'])));
        }
	else{
	   $supplierCount=$this->Supplier->find('count');
	}
        $this->set('supplierCount',$supplierCount);
        
        $this->loadModel('Soldbilling');
	if($userId!=1){
	    $saleAmount=$this->Soldbilling->query("SELECT SUM(finaltotal) as amount from soldbillings where user_id=$userId");

        }
	else{
	   $saleAmount=$this->Soldbilling->query("SELECT SUM(finaltotal) as amount from soldbillings");

	}
	
        $this->loadModel('Managereturnmedicine');
	
	if($userId!=1){
	    $returnAmount=$this->Managereturnmedicine->query("SELECT SUM(total) as amount from managereturnmedicines where user_id=$userId");

        }
	else{
	   $returnAmount=$this->Managereturnmedicine->query("SELECT SUM(total) as amount from managereturnmedicines");

	}
        //$tSaleAmount=$saleAmount[0][0]['amount']-$returnAmount[0][0]['amount'];
        $this->set('tSaleAmount',round($saleAmount[0][0]['amount'],2));
        $this->loadModel('Purchase');
	if($userId!=1){
	    $purchaseAmount=$this->Purchase->query("SELECT SUM(price) as amount from purchases where user_id=$userId");

        }
	else{
	   $purchaseAmount=$this->Purchase->query("SELECT SUM(price) as amount from purchases");

	}
        
        $this->set('purchaseAmount',round($purchaseAmount[0][0]['amount'],2));
                    
    }
    
    
    
    
    public function export()
    {
	$this->layout=null;
        $this->autoRender=false;
        try
        {
            $data=$this->exportData();
            $this->PhpExcel->createWorksheet();
            $this->PhpExcel->addTableRow($data);
            $this->PhpExcel->output('DataBackup',$this->siteName,'DataBackup.xls','Excel2007');
        }
        catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage(),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }    
    
    private function exportData()
    {
        $siteName=$this->siteOrganization;
        $post=$this->Product->find('all');
        $data=$this->showProductData($post);
        return $data;
    }
    private function showProductData($post)
    {
        
        $showData=array();
        if($post)
        {
       
            $showData=array(array(__('Invoice No'),__('Batch No'),__('Rack'),__('Category'),__('Medicine Name'),__('Packet * Quantity'),__('Quantity'),__('Remaining Quantity'),__('Price'),__('Discount (%)'),__('Tax (%)'),__('Net Price'),__('Price Per Piece'),__('Supplier Name'),__('Supplier Mobile'),__('Supplier Store Name'),__('Expiry Date'),__('Purchase Date')));
            
            foreach($post as $rank=>$value)
            {
                   if($value['Product']['expiry_date']){$expiryDate=CakeTime::format('d-M-Y',$value['Product']['expiry_date']);}else{$expiryDate=null;}
                   if($value['Product']['purchase_date']){$puchaseDate=CakeTime::format('d-M-Y',$value['Product']['purchase_date']);}else{$puchaseDate=null;}
                   $showData[]=array('Invoice No'=>$value['Product']['invoice_no'],'Batch No'=>$value['Product']['batch_no'],'Rack'=>$value['Rack']['name'],'Category'=>$value['Category']['name'],
                                  'Medicine Name'=>$value['Product']['name'],'Packet * Quantity'=>$value['Product']['packet'].'*'.$value['Product']['quantity_piece'],'Quantity'=>$value['Product']['packet']*$value['Product']['quantity_piece'],
                                  'Remaining Quantity'=>$value['Product']['qty'],'Price'=>$value['Product']['onlyprice'],'Discount (%)'=>$value['Product']['discount'],'Tax (%)'=>$value['Product']['tax'],
                                  'Net Price'=>$value['Product']['price'], 'Price Per Piece'=>$value['Product']['price_one_piece'],'Supplier Name'=>$value['Supplier']['name'],'Supplier Mobile'=>$value['Supplier']['mobile'],
                                  'Supplier Store Name'=>$value['Supplier']['store_name'],'Expiry Date'=>$expiryDate,'Purchase Date'=>$puchaseDate);
            }
            
        }
        else
        {
          $showData=array(array(__('No Record Found')));
         
        }
        return$showData;
    }
    public function download()
    {
        $this->viewClass = 'Media';
        $params = array(
            'id'        => 'sample-Product.xls',
            'name'      => 'SampleProduct',
            'download'  => true,
            'extension' => 'xls',
            'mimeType'  => array('xls' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
            'path'      => APP . 'tmp' . DS.'download'.DS
        );
        $this->set($params);
    }
    public function calc()
    {
         
    }
    
}