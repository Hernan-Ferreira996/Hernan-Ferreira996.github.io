<?php
class ManagereturnmedicinesController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg','PhpExcel.PhpExcel');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Managereturnmedicine.id'=>'desc'));
    public function index()
    {
	
        $cond=array();
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
         $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Managereturnmedicine.user_id'=>$userId);
        }
        $this->Paginator->settings['conditions'] = array($this->Managereturnmedicine->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
    public function printmedicinebill($billNum=null)
    {
	try{
	    $this->layout=null;
	    $this->loadModel('Soldbilling');
            if (!$billNum) {
            throw new NotFoundException(__('Invalid post'));
            }
	    $post=$this->Managereturnmedicine->find('all',array('conditions'=>array('Managereturnmedicine.bill_num'=>$billNum)));
            if (!$post) {
            throw new NotFoundException(__('Invalid post'));
            }
	    $post1=$this->Managereturnmedicine->find('first',array('conditions'=>array('Managereturnmedicine.bill_num'=>$billNum)));
	    $sold=$this->Soldbilling->findByBillNum($billNum);
            $billNum=$post1['Managereturnmedicine']['bill_num'];;
	    $date=$post1['Managereturnmedicine']['created'];
            $docName=$post1['Managereturnmedicine']['doctor_name'];
        $cusName=$post1['Managereturnmedicine']['customer_name'];
        $cusPhone=$post1['Managereturnmedicine']['customer_phone'];
	$cusId=$sold['Soldbilling']['customer_id'];
	$this->set('date',$date);
	$this->set('cusId',$cusId);
	$this->set('billNum',$billNum);
        $this->set('docName',$docName);
        $this->set('cusName',$cusName);
        $this->set('cusPhone',$cusPhone);
                $this->set('posts',$post);
        }
	catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage(),'flash',array('alert'=>'danger'));
        }
    }    
    public function deleteall()
    {
     if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            if ($this->request->is('post'))
            {
                foreach($this->data['Managereturnmedicine']['id'] as $key => $value)
                {
                    $this->Managereturnmedicine->delete($value);
                }
                $this->Session->setFlash(__('Return Medicine has been deleted!'),'flash',array('alert'=>'danger'));
            }        
            $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
    public function export()
    {
	$this->layout=null;
        $this->autoRender=false;
        try
        {
            $data=$this->exportData();
            $this->PhpExcel->createWorksheet();
            $this->PhpExcel->addTableRow($data);
            $this->PhpExcel->output('ManageReturnMedicine',$this->siteName,'ReturnMedicine.xls','Excel2007');
        }
        catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage(),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }    
    private function exportData()
    {
	$cond=array();
        $siteName=$this->siteOrganization;
	$userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Managereturnmedicine.user_id'=>$userId);
        }
        $post=$this->Managereturnmedicine->find('all',array('conditions'=>$cond));
        $data=$this->showProductData($post);
        return $data;
    }
   
    private function showProductData($post)
    {
        
        $showData=array();
        if($post)
        {
       
            $showData=array(array(__('Bill Num'),__('Medicine Name'),__('Quantity'),__('Price'),__('Total'),__('Doctor Name'),__('Customer Name'),__('Customer Phone'),__('Return Date')));
            
            foreach($post as $rank=>$value)
            {
                   if($value['Managereturnmedicine']['created']){$returnDate=CakeTime::format('d-M-Y',$value['Managereturnmedicine']['created']);}else{$returnDate=null;}
                   $showData[]=array('Bill Num'=>$value['Managereturnmedicine']['bill_num'],
                                  'Medicine Name'=>$value['Managereturnmedicine']['medicine_name'],'Quantity'=>$value['Managereturnmedicine']['quantity'],
                                  'Price'=>number_format($value['Managereturnmedicine']['price'],2),
				  'Total'=>number_format($value['Managereturnmedicine']['total'],2),
				  'Doctor Name'=>$value['Managereturnmedicine']['doctor_name'],
				  'Customer Name'=>$value['Managereturnmedicine']['customer_name'],'Customer Phone'=>$value['Managereturnmedicine']['customer_phone'],
                                  'Return Date'=>$returnDate);
            }
            
        }
        else
        {
          $showData=array(array(__('No Record Found')));
         
        }
        return$showData;
    }
    public function download()
    {
        $this->viewClass = 'Media';
        $params = array(
            'id'        => 'sample-Product.xls',
            'name'      => 'SampleProduct',
            'download'  => true,
            'extension' => 'xls',
            'mimeType'  => array('xls' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
            'path'      => APP . 'tmp' . DS.'download'.DS
        );
        $this->set($params);
    }
}
?>