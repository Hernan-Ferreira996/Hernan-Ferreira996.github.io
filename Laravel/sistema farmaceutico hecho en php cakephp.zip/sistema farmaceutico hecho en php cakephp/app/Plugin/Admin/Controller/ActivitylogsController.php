<?php
class ActivitylogsController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg');
    public $presetVars = true;
    var $paginate = array('limit'=>20,'maxLimit'=>500,'page'=>1,'order'=>array('Activitylog.id'=>'desc'));
    public function index($id=null)
    {
         if ($id==null)
         {
            $this->Paginator->settings=$this->paginate;
        }
        else
        {
            
         $this->Paginator->settings['conditions']=array('Activitylog.user_id'=>$id);
        }
        $this->Activitylog->virtualFields=array('duration'=>'logged_out-logged_in');
        
        
        $this->Prg->commonProcess();
        //$this->Paginator->settings = $this->paginate;
       // $this->Paginator->settings['conditions'] = $this->Activitylog->parseCriteria($this->Prg->parsedParams());
       $this->Paginator->settings['order'] =array('Activitylog.id'=>'desc');
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
       
    public function deleteall()
    {
     if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            if ($this->request->is('post'))
            {
                foreach($this->data['Activitylog']['id'] as $key => $value)
                {
                    $this->Activitylog->delete($value);
                }
                $this->Session->setFlash(__('Your Activity Log has been deleted.'),'flash',array('alert'=>'danger'));
            }        
            $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
}
?>