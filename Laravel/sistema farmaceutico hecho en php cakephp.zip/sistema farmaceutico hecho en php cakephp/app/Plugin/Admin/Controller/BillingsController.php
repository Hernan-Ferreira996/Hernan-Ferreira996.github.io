<?php
class BillingsController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg','CustomFunction');
    public $presetVars = true;
    //var $paginate = array('page'=>1,'order'=>array('Rack.name'=>'asc'));
    public function index()
    {
         $this->loadModel('Product');
         $this->loadModel('Member');
         $randomNumber=substr(rand(),0,8);
        //pr($this->request->data);die();
        /*if ($this->request->is('post'))
        {
            $this->Billing->create();
            $this->Billing->save($this->request->data);
            $productId=$this->request->data['Billing']['product_id'];
            $productQty=$this->request->data['Billing']['quantity'];
            $product=$this->Product->findById($productId);
            $totalQty=$product['Product']['qty']-$productQty;
            $record=array('id'=>$productId,'qty'=>$totalQty);
            $this->Product->save($record);
        }*/
        $bill_num=rand(1, 1000000);
        $this->set('count',$this->Billing->find('count'));
        $this->set('posts',$this->Billing->find('all'));
        $this->set('bill_num',$bill_num);
        $this->set('randomNumber',$randomNumber);
        
    }
    
    public function insertbilling()
    {
        //$this->autoRender = false;
        $randomNumber=substr(rand(),0,8);
        $bill_num=rand(1, 1000000);
        $this->layout=null;
        $this->request->onlyAllow('ajax');
        // get the search term from URL
        $this->loadModel('Product');
        if(strlen($this->request->data['product_id'])>0){
        $this->Billing->create();
            $this->Billing->save($this->request->data);
            $productId=$this->request->data['product_id'];
            $productQty=$this->request->data['quantity'];
            $product=$this->Product->findById($productId);
            $totalQty=$product['Product']['qty']-$productQty;
            $record=array('id'=>$productId,'qty'=>$totalQty);
            $this->Product->save($record);
        }
            $this->set('bill_num',$bill_num);
            $this->set('randomNumber',$randomNumber);
            $this->set('count',$this->Billing->find('count'));
            $this->set('posts',$this->Billing->find('all'));
        
    }
    public function search()
    {
        $this->loadModel('Product');
        $cond=array();
        $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Product.user_id'=>$userId);
        }
        $this->autoRender = false;
        $this->request->onlyAllow('ajax');
        // get the search term from URL
        
        $term = $this->request->query['q'];
        $records = $this->Product->find('all',array('conditions' => array('Product.name LIKE' => $term.'%','Product.qty >'=>0,$cond)));
        // Format the result for select2
        $result = array();
        foreach($records as  $key=>$value)
        {
            //$result[] = array('id' => $value['Product']['id'], 'text' => $value['Product']['name']);
            $result[$key]['id'] = $value['Product']['id'];
            $result[$key]['text'] = $value['Product']['name'].' ('.$value['Product']['batch_no'].')';
        }
        $product = $result;
        echo json_encode($product);
    }
    public function searchmember()
    {
        $this->loadModel('Member');
        $cond=array();
        $userId=$this->adminValue['User']['id'];
        //if($userId!=1){
        //$cond=array('Product.user_id'=>$userId);
        //}
        $this->autoRender = false;
        $this->request->onlyAllow('ajax');
        // get the search term from URL
        
        $term = $this->request->query['q'];
        $records = $this->Member->find('all',array('conditions' => array('Member.member_id' => $term,$cond)));
        // Format the result for select2
        $result = array();
        foreach($records as  $key=>$value)
        {
            //$result[] = array('id' => $value['Product']['id'], 'text' => $value['Product']['name']);
            $result[$key]['id'] = $value['Member']['id'];
            $result[$key]['text'] = $value['Member']['member_id'];
        }
        $product = $result;
        echo json_encode($product);
    }
    public function chkcusid()
    {
        $this->autoRender = false;
        $this->request->onlyAllow('ajax');
        // get the search term from URL
        $this->loadModel('Member');
        if(strlen($this->request->data['member_id']>0)){
        $id = $this->request->data['member_id'];
        $records = $this->Member->find('count',array('conditions'=>array('Member.member_id'=>$id)));
        echo $records;
        }
    }
    public function chkcusphone()
    {
        $this->autoRender = false;
        $this->request->onlyAllow('ajax');
        // get the search term from URL
        $this->loadModel('Member');
        if(strlen($this->request->data['customer_phone'])>0){
        $id = $this->request->data['customer_phone'];
        $records = $this->Member->find('count',array('conditions'=>array('Member.mobile'=>$id)));
        echo $records;
        }
    }
    public function quantity()
    {
        $this->autoRender = false;
        $this->request->onlyAllow('ajax');
        // get the search term from URL
        $this->loadModel('Product');
        if(strlen($this->request->data['products']>0)){
        $id = $this->request->data['products'];
        $records = $this->Product->findById($id);
            if($records){
            echo $records['Product']['qty'].'^&'.number_format($records['Product']['mrp'],2);
            }
        }
    }

    public function memberDetails()
    {
        $this->autoRender = false;
        $this->request->onlyAllow('ajax');
        // get the search term from URL
        $this->loadModel('Member');
        if(isset($this->request->data['memberId'])){
        $id = $this->request->data['memberId'];
        $records = $this->Member->findByMemberId($id);
        if($records){
        echo $records['Member']['member_id'].'^&'.$records['Member']['name'].'^&'.$records['Member']['mobile'].'^&'.$this->cashback($records['Member']['id']);
        }
        else{
            echo 'No';
        }
        }
    }
    private function cashback($id)
    {
        $amount=$this->CustomFunction->mwalletBalance($id);
        return$amount;
        
    }
    
    public function price()
    {
        $this->autoRender = false;
        $this->request->onlyAllow('ajax');
        // get the search term from URL
        $this->loadModel('Product');
        $id = $this->request->data['products'];
        $records = $this->Product->findById($id);
        echo number_format($records['Product']['price_one_piece'],2);
    }
    
    public function deleteall()
    {
      $this->loadModel('Product');  
       if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            if ($this->request->is('post'))
            {
               //pr($this->request->data);die(); 
                foreach($this->data['Billing']['id'] as $key => $value)
                {
                    if($value!=0){
                    $billing=$this->Billing->findById($value);
                    $billQty=$billing['Billing']['quantity'];
                    $productId=$billing['Billing']['product_id'];
                    $product=$this->Product->findById($productId);
                    $qty=$product['Product']['qty'];
                    $totalQty=$qty+$billQty;
                    $record=array('id'=>$productId,'qty'=>$totalQty);
                    $this->Product->save($record);
                    $this->Billing->delete($value);
                    }
                }
                $this->Session->setFlash(__('Item has been deleted.'),'flash',array('alert'=>'danger'));
            }        
            $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
    public function payment($bill_num=null)
    {
        $this->loadModel('Finalbilling');
        $this->loadModel('Soldbilling');
        $this->loadModel('Member');
        if (!$bill_num) {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is('post'))
        {
            //pr($this->request->data);die();
            if($this->request->data['Billing']['customer_name']!=""){$name=$this->request->data['Billing']['customer_name'];}else{$name=null;}
            if($this->request->data['Billing']['customer_phone']!=""){$mobile=$this->request->data['Billing']['customer_phone'];}else{$mobile=null;}
            if($this->request->data['Billing']['cus_type']=="New"){
                $memberRecord=array('status'=>'Active','member_id'=>$this->request->data['Billing']['customer_id'],'name'=>$name,'mobile'=>$mobile);
                $this->Member->create();
                $this->Member->save($memberRecord);
                $memberId=$this->Member->id;
            }
            else{
                $memberArr=$this->Member->findByMemberId(trim($this->request->data['Billing']['customer_id']));
                $memberId=$memberArr['Member']['id'];
            }
            $this->loadModel('Billing');
            $billing=$this->Billing->find('all');
            $sumQuantity=$this->Billing->query('select SUM(quantity) AS sum from tempbillings');
            
            foreach($billing as $k=>$post):
             if(isset($this->request->data['Billing']['totaldiscount'])){$finaldiscount=$this->request->data['Billing']['totaldiscount'];}else{$finaldiscount=Null;}
	if(isset($this->request->data['Billing']['totaltax'])){$finaltax=$this->request->data['Billing']['totaltax'];}else{$finaltax=Null;}
        if($k==0){
            
            $billTax=$this->request->data['Billing']['bill_tax'];
            
            
            if(isset($this->request->data['Billing']['cashbackamount'])){$cashbackamount=$this->request->data['Billing']['cashbackamount'];}else{$cashbackamount=Null;}
	if(isset($this->request->data['Billing']['paidamount'])){$finaltotal=$this->request->data['Billing']['paidamount'];}else{$finaltotal=$post['Billing']['paidamount'];}
        }
        else{
            $billTax=NULL;
            $finaltotal=NULL;
        }
	
	$actualtprice=$post['Billing']['tprice'];
	 if($finaldiscount || $finaltax || $cashbackamount){
            
         $calCashback1=$cashbackamount/$sumQuantity[0][0]['sum'];
         $calCashback=$calCashback1*$post['Billing']['quantity'];
         $tprice=$post['Billing']['tprice']-$calCashback;
	 $calcD1=$tprice-($tprice*$finaldiscount)/100;
	  $calcD2=($tprice*$finaltax)/100;
	   $calcD=$calcD1+$calcD2;
	 $unitPrice=$calcD/$post['Billing']['quantity'];
         
	 }
	 else{
            $tprice=$post['Billing']['tprice'];
		 $calcD=$tprice;
		 $unitPrice=$tprice/$post['Billing']['quantity'];
	 }
            $record[]=array('bill_tax'=>$billTax,'medicine_tax'=>$post['Billing']['medicine_tax'],'actualprice'=>$actualtprice,'member_id'=>$memberId,'cashback_percentage'=>$this->customerCashbackPercentage,'cashback'=>$cashbackamount,'product_id'=>$post['Billing']['product_id'],'user_id'=>$this->adminValue['User']['id'],'finaldiscount'=>$finaldiscount,'finaltax'=>$finaltax,'total'=>$tprice,'bill_num'=>$bill_num,'finaltotal'=>$finaltotal,'calcD'=>$calcD,'unitprice'=>$unitPrice,'tax'=>$post['Billing']['tax'],'discount'=>$post['Billing']['discount'],'price'=>$post['Billing']['price'],'quantity'=>$post['Billing']['quantity'],'medicine_name'=>$post['Product']['name'],'doctor_name'=>$this->request->data['Billing']['doctor_name'],'customer_id'=>$this->request->data['Billing']['customer_id'],'customer_name'=>$this->request->data['Billing']['customer_name'],'customer_phone'=>$this->request->data['Billing']['customer_phone']);
            endforeach;unset($post);
            $this->Finalbilling->saveAll($record);
	$this->Soldbilling->saveAll($record);
        $soldBillingId=$this->Soldbilling->id;
        
        if($this->request->data['Billing']['cashback']=="on"){
        $amount=($finaltotal * $this->customerCashbackPercentage)/100;
        $remarks="Amount $amount added in your wallet";
        $this->CustomFunction->mwalletInsert($memberId,$amount,"CR",$remarks,$soldBillingId);
        }
        if(isset($this->request->data['Billing']['cashbackamount'])){
        $amount=$this->request->data['Billing']['cashbackamount'];
        $remarks="Amount $amount Deducted from your wallet";
        $this->CustomFunction->mwalletInsert($memberId,$amount,"DR",$remarks);
        }
        $this->Billing->query('delete from tempbillings');
        }
        $posts=$this->Soldbilling->find('all',array('conditions'=>array('Soldbilling.bill_num'=>$bill_num)));
        $sold=$this->Soldbilling->find('first',array('conditions'=>array('Soldbilling.bill_num'=>$bill_num)));
        $date=$sold['Soldbilling']['created'];
        $cusName=$sold['Soldbilling']['customer_name'];
        $finaltotal=$sold['Soldbilling']['finaltotal'];
        $docName=$sold['Soldbilling']['doctor_name'];
        $cusId=$sold['Soldbilling']['customer_id'];
        $cusPhone=$sold['Soldbilling']['customer_phone'];
        $cashbackValue=$sold['Soldbilling']['cashback'];
        $this->set('posts',$posts);
        $this->set('docName',$docName);
        $this->set('cusId',$cusId);
        $this->set('cusName',$cusName);
        $this->set('cashbackValue',$cashbackValue);
        $this->set('cusPhone',$cusPhone);
        $this->set('date',$date);
        $this->set('finaltotal',$finaltotal);
        $this->set('bill_num',$bill_num);
    }
    public function printbill($bill_num=null)
    {
        $this->layout=null;
        $this->loadModel('Finalbilling');
        $this->loadModel('Soldbilling');
        if (!$bill_num) {
            throw new NotFoundException(__('Invalid post'));
        }
        
        $posts=$this->Soldbilling->find('all',array('conditions'=>array('Soldbilling.bill_num'=>$bill_num)));
        $sold=$this->Soldbilling->find('first',array('conditions'=>array('Soldbilling.bill_num'=>$bill_num)));
        $date=$sold['Soldbilling']['created'];
        $finaltotal=$sold['Soldbilling']['finaltotal'];
        $cashbackValue=$sold['Soldbilling']['cashback'];
        $docName=$sold['Soldbilling']['doctor_name'];
        $cusId=$sold['Soldbilling']['customer_id'];
        $cusName=$sold['Soldbilling']['customer_name'];
        $cusPhone=$sold['Soldbilling']['customer_phone'];
        $this->set('posts',$posts);
        $this->set('docName',$docName);
        $this->set('cusId',$cusId);
        $this->set('cusName',$cusName);
        $this->set('cashbackValue',$cashbackValue);
        $this->set('cusPhone',$cusPhone);
        $this->set('date',$date);
        $this->set('finaltotal',$finaltotal);
        $this->set('bill_num',$bill_num);
    }
    public function deleteitem()
    {
        $this->layout=null;
      $this->loadModel('Product');  
       if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            $randomNumber=substr(rand(),0,8);
        $bill_num=rand(1, 1000000);
            if ($this->request->is('post'))
            {
               //pr($this->request->data);die();
                $idArr=explode(",",$this->request->data['id']);
                foreach($idArr as $key => $value)
                {
                    if($value!=0){
                    $billing=$this->Billing->findById($value);
                    $billQty=$billing['Billing']['quantity'];
                    $productId=$billing['Billing']['product_id'];
                    $product=$this->Product->findById($productId);
                    $qty=$product['Product']['qty'];
                    $totalQty=$qty+$billQty;
                    $record=array('id'=>$productId,'qty'=>$totalQty);
                    $this->Product->save($record);
                    $this->Billing->delete($value);
                    }
                }
                $this->set('bill_num',$bill_num);
            $this->set('randomNumber',$randomNumber);
            $this->set('count',$this->Billing->find('count'));
            $this->set('posts',$this->Billing->find('all'));
                //$this->Session->setFlash(__('Item has been deleted.'),'flash',array('alert'=>'danger'));
            }        
            $this->render('insertbilling',null);
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
    
}
?>