<?php
App::uses('ConnectionManager', 'Model');
ini_set('max_execution_time', 900);
class BackupsController extends AdminAppController {
    public function index()
    {
        $this->autoRender=false;
        $dataSource = ConnectionManager::getDataSource('default');
        $dbName = $dataSource->config['database'];
        $this->exportDatabase($dbName);     
    }
    private function exportDatabase($dbName, $backup_name=false )
    {
        $databaseName="Tables_in_".$dbName;
        $content=null;
        $this->Backup->query("SET NAMES 'utf8'");

        $queryTables    = $this->Backup->query('SHOW TABLES');
        foreach($queryTables as $row)
        { 
            $target_tables[] = $row['TABLE_NAMES'][$databaseName]; 
        }
        foreach($target_tables as $table)
        {
            $result         =    $this->Backup->query('SELECT * FROM '.$table);  
            $fields_amount_arr  =   $this->Backup->query("SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS WHERE table_schema = '$dbName' AND table_name = '$table'");
            $fields_amount=$fields_amount_arr[0][0]['count'];
            $rows_num=$this->Backup->getAffectedRows();
            $res            =    $this->Backup->query('SHOW CREATE TABLE '.$table);
            $TableMLine     =   $res[0][0]['Create Table'];
			$content.= "\nDROP TABLE IF EXISTS `".$table."`;";
            $content        = (!isset($content) ?  '' : $content) . "\n\n".$TableMLine.";\n\n";

            for ($i = 0, $st_counter = 0; $i < $fields_amount;   $i++, $st_counter=0) 
            {
                foreach($result as $row)  
                { //when started (and every after 100 command cycle):
                    if ($st_counter%100 == 0 || $st_counter == 0 )  
                    {
                            $content .= "\nINSERT INTO ".$table." VALUES";
                    }
                    $content .= "\n(";
                    foreach($row[$table] as $j=>$value)  
                    {
                        $row[$j]=$value;
                        $row[$j] = str_replace("\n","\\n", addslashes($row[$j]) ); 
                        if (isset($row[$j]))
                        {
                            $content .= '"'.$row[$j].'"' ; 
                        }
                        else 
                        {   
                            $content .= '""';
                        }     
                        if ($j<($fields_amount-1))
                        {
                                $content.= ',';
                        }      
                    }
                    $content .=")";
                    //every after 100 command cycle [or at last line] ....p.s. but should be inserted 1 cycle eariler
                    if ( (($st_counter+1)%100==0 && $st_counter!=0) || $st_counter+1==$rows_num) 
                    {   
                        $content .= ";";
                    } 
                    else 
                    {
                        $content .= ",";
                    } 
                    $st_counter=$st_counter+1;
                }
            } $content .="\n\n\n";
        }
        //$backup_name = $backup_name ? $backup_name : backup."___(".date('h-i-s A')."_".date('d-m-Y').").sql";
        //$backup_name = $backup_name ? $backup_name : $name.".sql";
		$backup_name = $backup_name ? $backup_name : "Backup(".date('d-m-Y H:i:s').")".".sql";
        header('Content-Type: application/octet-stream');   
        header("Content-Transfer-Encoding: Binary"); 
        header("Content-disposition: attachment; filename=\"".$backup_name."\"");  
        echo $content; exit;
    } 
}
