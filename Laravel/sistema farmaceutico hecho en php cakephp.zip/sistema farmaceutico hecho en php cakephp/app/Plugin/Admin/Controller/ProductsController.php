<?php
class ProductsController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg','PhpExcel.PhpExcel');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Product.name'=>'asc'));
    public function index()
    {
        $cond=array();
        $currentDate=date('Y-m-d');
	$currentDay=date('d');
        if(isset($this->params['named']['expiry_date']) && strlen($this->params['named']['expiry_date'])>0)
        {
            $ts = mktime(0, 0, 0, date("n") + $this->params['named']['expiry_date'], $currentDay);
	    $testMonth= date("Y-m-d ", $ts);
            $cond[]=array('Product.expiry_date BETWEEN ? AND ?'=>array($currentDate,$testMonth));
        }
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
        $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Product.user_id'=>$userId);
        }
        $this->Paginator->settings['conditions'] = array($this->Product->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
    public function add()
    {
        $this->loadModel('Purchase');
        $this->loadModel('Rack');
        $this->set('rack',$this->Rack->find('list',array('conditions'=>array('Rack.user_id'=>$this->adminValue['User']['id']),
                                                         'order'=>array('Rack.name'=>'asc'))));
        $this->loadModel('Category');
        $this->set('category',$this->Category->find('list',array('conditions'=>array('Category.user_id'=>$this->adminValue['User']['id']),
                                                                 'order'=>array('Category.name'=>'asc'))));
        $this->loadModel('Supplier');
        $this->Supplier->virtualFields=array('Supplier' => 'CONCAT(Supplier.name, " ( Mobile : ",Supplier.mobile, " ) ")');
        $supplier=$this->Supplier->find('list',array('fields'=>array('id','Supplier'),
                                                     'conditions'=>array('Supplier.user_id'=>$this->adminValue['User']['id']),
                                                     'order'=>array('Supplier.name'=>'asc')));
        $this->set('supplier',$supplier);
        if(!$this->userPermissionArr['save_right'])
        {
         $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        if ($this->request->is('post'))
        {
            $this->Product->create();
            try
            {
if(isset($this->request->data['Product']['discount']) || isset($this->request->data['Product']['tax'])){
$onlyprice=$this->request->data['Product']['onlyprice'];    
$discount= $this->request->data['Product']['discount'];
$tax=$this->request->data['Product']['tax'];

$total= ($onlyprice*$discount)/100;
$price1=$onlyprice-$total;
$total=($onlyprice*$tax)/100;
$price=$price1+$total;
}
else{

$price=$onlyprice; 

}

                
                
                
                $this->request->data['Product']['price']=$price;
                $this->request->data['Product']['user_id']=$this->adminValue['User']['id'];
                $this->request->data['Product']['qty']=$this->request->data['Product']['packet']*$this->request->data['Product']['quantity_piece'];
                $this->request->data['Product']['price_one_piece']=$price/$this->request->data['Product']['qty'];
                
                
               
                if ($this->Product->save($this->request->data))
                {
                    $lastId=$this->Product->id;
                    $productRecord=$this->Product->findById($lastId);
                    $purchaseRecord['Purchase']=$productRecord['Product'];
                    $this->Purchase->save($purchaseRecord);
                    
                    $this->Session->setFlash(__('Product has been added!'),'flash',array('alert'=>'success'));
                    return $this->redirect(array('action' => 'add'));
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash(__('Invalid Post'),'flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }
    }
    /*
    public function edit($id = null)
    {
      if(!$this->userPermissionArr['update_right'])
     {
     $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
     return $this->redirect(array('action' => 'index'));
     }
        if (!$id)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        $ids=explode(",",$id);
        $post=array();
        foreach($ids as $id)
        {
            $post[]=$this->Product->findByid($id);
        }
        $this->set('Product',$post);
        if (!$post)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is(array('post', 'put')))
        {
            try
            {
                if ($this->Product->saveAll($this->request->data))
                {
                    $this->Session->setFlash(__('Product has been updated!'),'flash',array('alert'=>'success'));
                    return $this->redirect(array('action' => 'index'));
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash(__('Invalid Post.'),'flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
            $this->set('isError',true);
        }
        else
        {
            $this->layout = null;
            $this->set('isError',false);
        }
        if (!$this->request->data)
        {
            $this->request->data = $post;
        }
    }
    */
    public function deleteall()
    {
     if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            if ($this->request->is('post'))
            {
                foreach($this->data['Product']['id'] as $key => $value)
                {
                    $this->Product->delete($value);
                }
                $this->Session->setFlash(__('Product has been deleted!'),'flash',array('alert'=>'danger'));
            }        
            $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
    public function view($id = null)
    {
     $this->layout = null;
        if (!$id) {
            throw new NotFoundException(__('Invalid post'));
        }

        $post = $this->Product->findById($id);
        if (!$post) {
            throw new NotFoundException(__('Invalid post'));
        }
       
        $this->set('post', $post);
        
    }
    
    public function search()
    {
        $this->autoRender = false;
        $this->request->onlyAllow('ajax');
        // get the search term from URL
        $this->loadModel('Medicine');
        $term = $this->request->query['key'];
        $records = $this->Medicine->find('all',array('conditions' => array('Medicine.name LIKE' => $term.'%')));
        // Format the result for select2
        $result = array();
        foreach($records as  $value)
        {  
            $result[] = $value['Medicine']['name'];
        }     
        echo json_encode($result);
    }
    public function export()
    {
	$this->layout=null;
        $this->autoRender=false;
        try
        {
            $data=$this->exportData();
            $this->PhpExcel->createWorksheet();
            $this->PhpExcel->addTableRow($data);
            $this->PhpExcel->output('Product',$this->siteName,'Product.xls','Excel2007');
        }
        catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage(),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }    
    
    private function exportData()
    {
	$cond=array();
        $siteName=$this->siteOrganization;
	$userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Product.user_id'=>$userId);
        }
        $post=$this->Product->find('all',array('conditions'=>$cond));
        $data=$this->showProductData($post);
        return $data;
    }
    private function showProductData($post)
    {
        
        $showData=array();
        if($post)
        {
       
            $showData=array(array(__('Invoice No'),__('Batch No'),__('Rack'),__('Category'),__('Medicine Name'),__('Packet * Quantity'),__('Quantity'),__('Remaining Quantity'),__('Price'),__('Discount (%)'),__('Tax (%)'),__('Net Price'),__('Price Per Piece'),__('Supplier Name'),__('Supplier Mobile'),__('Supplier Store Name'),__('Expiry Date'),__('Purchase Date')));
            
            foreach($post as $rank=>$value)
            {
                   if($value['Product']['expiry_date']){$expiryDate=CakeTime::format('d-M-Y',$value['Product']['expiry_date']);}else{$expiryDate=null;}
                   if($value['Product']['purchase_date']){$puchaseDate=CakeTime::format('d-M-Y',$value['Product']['purchase_date']);}else{$puchaseDate=null;}
                   $showData[]=array('Invoice No'=>$value['Product']['invoice_no'],'Batch No'=>$value['Product']['batch_no'],'Rack'=>$value['Rack']['name'],'Category'=>$value['Category']['name'],
                                  'Medicine Name'=>$value['Product']['name'],'Packet * Quantity'=>$value['Product']['packet'].'*'.$value['Product']['quantity_piece'],'Quantity'=>$value['Product']['packet']*$value['Product']['quantity_piece'],
                                  'Remaining Quantity'=>$value['Product']['qty'],'Price'=>$value['Product']['onlyprice'],'Discount (%)'=>$value['Product']['discount'],'Tax (%)'=>$value['Product']['tax'],
                                  'Net Price'=>$value['Product']['price'], 'Price Per Piece'=>$value['Product']['price_one_piece'],'Supplier Name'=>$value['Supplier']['name'],'Supplier Mobile'=>$value['Supplier']['mobile'],
                                  'Supplier Store Name'=>$value['Supplier']['store_name'],'Expiry Date'=>$expiryDate,'Purchase Date'=>$puchaseDate);
            }
            
        }
        else
        {
          $showData=array(array(__('No Record Found')));
         
        }
        return$showData;
    }
    public function download()
    {
        $this->viewClass = 'Media';
        $params = array(
            'id'        => 'sample-Product.xls',
            'name'      => 'SampleProduct',
            'download'  => true,
            'extension' => 'xls',
            'mimeType'  => array('xls' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
            'path'      => APP . 'tmp' . DS.'download'.DS
        );
        $this->set($params);
    }
}
?>