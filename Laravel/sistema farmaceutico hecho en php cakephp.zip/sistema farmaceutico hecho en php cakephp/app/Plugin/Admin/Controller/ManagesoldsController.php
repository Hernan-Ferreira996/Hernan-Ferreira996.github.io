<?php
class ManagesoldsController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg','PhpExcel.PhpExcel');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Managesold.id'=>'desc'));
    public function index()
    {
        $cond=array();
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
         $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Managesold.user_id'=>$userId);
        }
	$this->Paginator->settings['conditions'] = array($this->Managesold->parseCriteria($this->Prg->parsedParams()),$cond);
	$this->Paginator->settings['fields']=array('DISTINCT Managesold.bill_num');
	$this->Paginator->settings['order']=array('Managesold.id'=>'asc');
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
    public function printsoldbill($bill_num=null)
    {
	try{
	    $this->layout=null;
        $this->loadModel('Finalbilling');
        $this->loadModel('Soldbilling');
        if (!$bill_num) {
            throw new NotFoundException(__('Invalid post'));
        }
        
        $posts=$this->Soldbilling->find('all',array('conditions'=>array('Soldbilling.bill_num'=>$bill_num)));
        $sold=$this->Soldbilling->find('first',array('conditions'=>array('Soldbilling.bill_num'=>$bill_num)));
        $date=$sold['Soldbilling']['created'];
	$cusId=$sold['Soldbilling']['customer_id'];
        $cusName=$sold['Soldbilling']['customer_name'];
        $cusPhone=$sold['Soldbilling']['customer_phone'];
	$docName=$sold['Soldbilling']['doctor_name'];
	$finaltotal=$sold['Soldbilling']['finaltotal'];
	$cashbackValue=$sold['Soldbilling']['cashback'];
	$this->set('cashbackValue',$cashbackValue);
        $this->set('posts',$posts);
	$this->set('docName',$docName);
	$this->set('cusId',$cusId);
        $this->set('cusName',$cusName);
        $this->set('cusPhone',$cusPhone);
        $this->set('date',$date);
	$this->set('finaltotal',$finaltotal);
        $this->set('bill_num',$bill_num);
        }
	catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage(),'flash',array('alert'=>'danger'));
        }
    }    
    public function deleteall()
    {
     if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            if ($this->request->is('post'))
            {
                foreach($this->data['Soldbilling']['id'] as $key => $value)
                {
                    $this->Managesold->delete($value);
                }
                $this->Session->setFlash(__('Sold Medicine has been deleted!'),'flash',array('alert'=>'danger'));
            }        
            $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
    public function export()
    {
	$this->layout=null;
        $this->autoRender=false;
        try
        {
            $data=$this->exportData();
            $this->PhpExcel->createWorksheet();
            $this->PhpExcel->addTableRow($data);
            $this->PhpExcel->output('Managesold',$this->siteName,'ManageSold.xls','Excel2007');
        }
        catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage(),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }    
    private function exportData()
    {
	$cond=array();
        $siteName=$this->siteOrganization;
	$userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Managesold.user_id'=>$userId);
        }
        $post=$this->Managesold->find('all',array('conditions'=>$cond));
        $data=$this->showProductData($post);
        return $data;
    }
    
    private function showProductData($post)
    {
        
        $showData=array();
        if($post)
        {
       
            $showData=array(array(__('Bill Num'),__('Medicine Name'),__('Quantity'),__('Price'),__('Discount (%)'),__('Tax (%)'),__('Total'),__('Purchase Date'),__('Doctor Name'),__('Customer ID'),__('Customer Name'),__('Customer Contact')));
            
            foreach($post as $rank=>$value)
            {
                   if($value['Managesold']['created']){$PurchaseDate=CakeTime::format('d-M-Y',$value['Managesold']['created']);}else{$PurchaseDate=null;}
                   $showData[]=array('Bill Num'=>$value['Managesold']['bill_num'],'Medicine Name'=>$value['Managesold']['medicine_name'],'Quantity'=>$value['Managesold']['quantity'],
                                    'Price'=>number_format($value['Managesold']['price'],2),'Discount (%)'=>$value['Managesold']['discount'],'Tax (%)'=>$value['Managesold']['tax'],
				    'Total'=>number_format($value['Managesold']['total'],2),
                                    'Purchase Date'=>$PurchaseDate,'Doctor Name'=>$value['Managesold']['doctor_name'],'Customer ID'=>$value['Managesold']['customer_id'],'Customer Name'=>$value['Managesold']['customer_name'],'Customer Contact'=>$value['Managesold']['customer_phone']);
            }
            
        }
        else
        {
          $showData=array(array(__('No Record Found')));
         
        }
        return$showData;
    }
    public function download()
    {
        $this->viewClass = 'Media';
        $params = array(
            'id'        => 'sample-Product.xls',
            'name'      => 'SampleProduct',
            'download'  => true,
            'extension' => 'xls',
            'mimeType'  => array('xls' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
            'path'      => APP . 'tmp' . DS.'download'.DS
        );
        $this->set($params);
    }
}
?>