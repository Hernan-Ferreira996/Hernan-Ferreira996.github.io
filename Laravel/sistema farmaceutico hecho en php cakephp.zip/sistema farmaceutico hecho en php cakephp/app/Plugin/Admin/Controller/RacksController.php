<?php
class RacksController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Rack.name'=>'asc'));
    public function index()
    {
        $cond=array();
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
         $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Rack.user_id'=>$userId);
        }
        $this->Paginator->settings['conditions'] = array($this->Rack->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
    public function add()
    {
        if(!$this->userPermissionArr['save_right'])
        {
         $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        if ($this->request->is('post'))
        {
            $this->Rack->create();
            try
            {
                $this->request->data['Rack']['user_id']=$this->adminValue['User']['id'];
                if ($this->Rack->save($this->request->data))
                {
                    $this->Session->setFlash(__('Rack has been added!'),'flash',array('alert'=>'success'));
                    return $this->redirect(array('action' => 'add'));
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash(__('Invalid Post'),'flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }
    }
    public function edit($id = null)
    {
      if(!$this->userPermissionArr['update_right'])
     {
     $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
     return $this->redirect(array('action' => 'index'));
     }
        if (!$id)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        $ids=explode(",",$id);
        $post=array();
        foreach($ids as $id)
        {
            $post[]=$this->Rack->findByid($id);
        }
        $this->set('Rack',$post);
        if (!$post)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is(array('post', 'put')))
        {
            try
            {
                if ($this->Rack->saveAll($this->request->data))
                {
                    $this->Session->setFlash(__('Rack has been updated!'),'flash',array('alert'=>'success'));
                    return $this->redirect(array('action' => 'index'));
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash(__('Invalid Post.'),'flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
            $this->set('isError',true);
        }
        else
        {
            $this->layout = null;
            $this->set('isError',false);
        }
        if (!$this->request->data)
        {
            $this->request->data = $post;
        }
    }    
    public function deleteall()
    {
     if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            if ($this->request->is('post'))
            {
                foreach($this->data['Rack']['id'] as $key => $value)
                {
                    $this->Rack->delete($value);
                }
                $this->Session->setFlash(__('Rack has been deleted!'),'flash',array('alert'=>'danger'));
            }        
            $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
}
?>