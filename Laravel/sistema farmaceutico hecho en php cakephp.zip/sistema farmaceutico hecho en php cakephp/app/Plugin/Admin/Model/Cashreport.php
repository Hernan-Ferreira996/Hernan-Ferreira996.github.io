<?php
class Cashreport extends AppModel
{
    public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    public $useTable='soldbillings';
    //public $filterArgs = array('start_date' => array('type' => 'like','field'=>'Cashreport.created'),'end_date' => array('type' => 'like','field'=>'Cashreport.created'));
      public $filterArgs = array('');
                            

}
?>