<?php
class Salereturnreport extends AppModel
{
    public $useTable = 'managereturnmedicines';
}
?>