<?php
class Returnmedicine extends AppModel
{
    public $validationDomain = 'validation';
    public $useTable='finalbillings';
    //public $belongsTo=array('Supplier');
    public $actsAs = array('search-master.Searchable');
    public $filterArgs = array('bill_num' => array('field'=>'bill_num'),
                               'customer_phone' => array('field'=>'customer_phone'));
  
                            

}
?>