<?php
class Salesreport extends AppModel
{
    public $useTable = 'soldbillings';
}
?>