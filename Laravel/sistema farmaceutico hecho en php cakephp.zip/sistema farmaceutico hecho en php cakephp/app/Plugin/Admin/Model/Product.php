<?php
class Product extends AppModel
{
    public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    public $belongsTo=array('Rack','Category','Supplier');
    public $filterArgs = array('qty' => array('field'=>'Product.qty <='),
                               //'expiry_date' => array('type' => 'like','field'=>'Product.expiry_date'),
                               'keyword' => array('type' => 'like','field'=>array('Product.invoice_no','Product.batch_no','Rack.name','Category.name','Product.name','Product.qty')));
    /*public $validate =array('name' => array('alphaNumeric'=>array('rule' =>'alphaNumericCustom','required'=>true,'allowEmpty'=>false,'message'=>'Only Alphabets')),
                                            );*/
    
     public function beforeValidate($options = array())
     {
      if (!empty($this->data['Product']['purchase_date'])) {
      $this->data['Product']['purchase_date'] = $this->dateFormatBeforeSave($this->data['Product']['purchase_date']);
      }
      if (!empty($this->data['Product']['expiry_date'])) {
      $this->data['Product']['expiry_date'] = $this->dateFormatBeforeSave($this->data['Product']['expiry_date']);
      }
      
      return true;
   } 
                            

}
?>