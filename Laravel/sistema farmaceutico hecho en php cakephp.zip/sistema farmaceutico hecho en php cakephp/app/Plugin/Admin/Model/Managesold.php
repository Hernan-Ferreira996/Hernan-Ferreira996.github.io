<?php
class Managesold extends AppModel
{
    public $validationDomain = 'validation';
    public $useTable='soldbillings';
    public $actsAs = array('search-master.Searchable');
    public $filterArgs = array('keyword' => array('type' => 'like','field'=>array('Managesold.bill_num','Managesold.medicine_name','Managesold.quantity','Managesold.total','Managesold.price','Managesold.discount','Managesold.tax','Managesold.customer_name','Managesold.customer_phone')));
    
    //public $belongsTo=array('Supplier');

}
?>