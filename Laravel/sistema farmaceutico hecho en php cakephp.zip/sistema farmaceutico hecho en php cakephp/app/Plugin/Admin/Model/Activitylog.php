<?php
class Activitylog extends AppModel
{
     public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    public $filterArgs = array('keyword' => array('type' => 'like','field'=>'User.name'));
    public $belongsTo=array('User');
}    

?>