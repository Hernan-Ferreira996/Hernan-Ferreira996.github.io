<?php
class Managereturnmedicine extends AppModel
{
    public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    //public $useTable='managereturnmedicines';
    public $filterArgs = array('keyword' => array('type' => 'like','field'=>array('Managereturnmedicine.bill_num','Managereturnmedicine.medicine_name','Managereturnmedicine.quantity','Managereturnmedicine.price','Managereturnmedicine.total','Managereturnmedicine.customer_name','Managereturnmedicine.customer_phone')));
    //public $belongsTo=array('Supplier');

}
?>