<?php
class Member extends AppModel
{
  public $validationDomain = 'validation';
  public $hasOne=array('Mwallet');
  public $actsAs = array('search-master.Searchable');   
  public $filterArgs = array('keyword' => array('type' => 'like','field'=>array('Member.member_id','Member.name','Member.email','Member.mobile','Member.status','Mwallet.balance')));
  public $validate = array('member_id' => array('isUnique'=>array('required' => true,'rule' => 'isUnique','allowEmpty' => false,'message' => 'This Customer ID has been already  taken.')),
			   'name' => array('alphaNumeric' => array('rule' => '/^[a-z0-9 .-]*$/i','required' => true,'allowEmpty' => false,'message' => 'Only letters and numbers allowed')),
			   'mobile' => array('isUnique'=>array('rule' => 'isUnique','allowEmpty' => true,'message' => 'This Phone/Mobile No. has been already taken.'),
                                            'numeric'=>array('rule'=>'numeric','message'=>'Only Number'),
                                            //'between'=>array('rule'=>array('maxLength','10'),'message'=>'Only 10 Number'),
                                            //'between'=>array('rule'=>array('minLength','10'),'message'=>'Only 10 Number')
					    ),
                           'email' => array('email'=>array('rule' => 'email','message' => 'Enter a valid email','allowEmpty' => true)),
                           'address' => array('alphaNumeric' => array('allowEmpty' => true,'rule' => '/^[a-z0-9 \/ \s\\\\,-.:]*$/i','required' => true,'message' => 'Only letters and numbers allowed')),
			   );
}
?>