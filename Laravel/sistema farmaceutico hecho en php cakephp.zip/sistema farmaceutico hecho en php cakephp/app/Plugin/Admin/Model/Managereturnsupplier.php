<?php
class Managereturnsupplier extends AppModel
{
    public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    public $filterArgs = array('keyword' => array('type' => 'like','field'=>array('Managereturnsupplier.invoice_no','Managereturnsupplier.medicine_name','Managereturnsupplier.qty','Managereturnsupplier.price','Supplier.mobile')));
    public $useTable='returnproductsuppliers';
    public $belongsTo=array('Supplier');

}
?>