<?php
class MwalletHistory extends AppModel
{
  public $belongsTo=array('Member');
  public $actsAs = array('search-master.Searchable');
  public $filterArgs = array('keyword' => array('type' => 'like','field'=>array('Member.name','Member.member_id','MwalletHistory.amount','MwalletHistory.type','MwalletHistory.date','MwalletHistory.remarks')));
}
?>