<?php
class Supplierreport extends AppModel
{
    public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    public $useTable='purchases';
    public $belongsTo=array('Rack','Category','Supplier');
    public $filterArgs = array(//'qty' => array('field'=>'Product.qty <='),
                               //'expiry' => array('field' => 'Product.expiry_date BETWEEN ? AND ?'),
                               'keyword' => array('type' => 'like','field'=>array('Supplierreport.invoice_no','Supplier.name','Supplier.mobile','Supplier.address','Supplier.store_name','Supplierreport.name','Supplierreport.qty','Supplierreport.price')));
    /*public $validate =array('name' => array('alphaNumeric'=>array('rule' =>'alphaNumericCustom','required'=>true,'allowEmpty'=>false,'message'=>'Only Alphabets')),
                                            );*/
    
     
                            

}
?>