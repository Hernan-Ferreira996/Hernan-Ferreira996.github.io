<?php
class Purchasereport extends AppModel
{
    public $useTable = 'purchases';
}
?>