<?php
class Purchasereturnreport extends AppModel
{
    public $useTable = 'returnproductsuppliers';
}
?>