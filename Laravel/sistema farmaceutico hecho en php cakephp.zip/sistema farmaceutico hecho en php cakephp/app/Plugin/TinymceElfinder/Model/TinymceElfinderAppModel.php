<?php
App::uses('AppModel', 'Model');

class TinymceElfinderAppModel extends AppModel {

}