<?php
class AjaxcontentsController extends AppController
{
    public $helpers = array('Html', 'Form');
    public function designation()
    {
        $this->layout=null;
        $this->request->onlyAllow('ajax');
        $id = $this->request->query('id');
        $this->loadModel('DepartmentsDesignation');
        $designation=$this->DepartmentsDesignation->find('list',array('conditions'=>array('department_id'=>$id),'order'=>array('DepartmentsDesignation.name'=>'asc')));
        $this->set(compact('designation'));
    }
    
}
