<?php
class MyleavesController extends AppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Myleafe.id'=>'desc'));
    public function beforeFilter()
    {
        parent::beforeFilter();
        $this->authenticate();
        $this->userId=$this->userValue['User']['id'];
    }
    public function index()
    {
        $cond=array();
        $cond=array('Myleafe.employee_id'=>$this->userId);
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
        $this->Paginator->settings['conditions'] =array($this->Myleafe->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
    
    public function add()
    {
        $this->loadModel('Leavetype');
        $leave=$this->Leavetype->find('list',array('order'=>array('name'=>'asc')));
        $this->set('leave',$leave);
        
         if ($this->request->is(array('post', 'put')))
        {
            try
            {
                $this->Myleafe->create();
                $this->request->data['Myleafe']['employee_id']=$this->userId;
                if($this->Myleafe->saveAll($this->request->data))
                {     
                   $this->Session->setFlash(__('Leave Application Succesfully Send !'),'flash',array('alert'=>'success'));
                   return $this->redirect(array('action' => 'add'));
                }
                
                
            }
            catch (Exception $e)
            {
                $this->Session->setFlash($e->getMessage,'flash',array('alert'=>'danger'));
            }
        }
    }
    
    
}
?>