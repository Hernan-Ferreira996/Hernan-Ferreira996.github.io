<?php
class Myleafe  extends AppModel
{
    public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    public $useTable='applications';
    public $belongsTo=array('Leavetype');
    public $filterArgs = array('keyword' => array('type' => 'like','field'=>'Leavetype.name'));
    
    public function beforeValidate($options = array())
     {
      if (!empty($this->data['Myleafe']['leave_date'])) {
      $this->data['Myleafe']['leave_date'] = $this->dateFormatBeforeSave($this->data['Myleafe']['leave_date']);
      }
      
      return true;
   } 
    
}
?>