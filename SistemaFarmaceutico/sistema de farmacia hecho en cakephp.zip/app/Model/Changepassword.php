<?php
class Changepassword extends AppModel
{
   public $validationDomain = 'validation';
  public $useTable="employees";
}
?>