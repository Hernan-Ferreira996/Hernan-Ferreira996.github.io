<?php
class Supplier extends AppModel
{
    public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    public $filterArgs = array('keyword' => array('type' => 'like','field'=>array('Supplier.name','Supplier.mobile','Supplier.address','Supplier.store_name')));
    public $validate =array('name' => array('alphaNumeric'=>array('rule' =>'alphaNumericCustom','required'=>true,'allowEmpty'=>false,'message'=>'Only Alphabets')),
                            'address' => array('alphaNumeric'=>array('rule' =>'alphaNumericCustom','required'=>true,'allowEmpty'=>true,'message'=>'Only Alphabets')),
                            'store_name' => array('alphaNumeric'=>array('rule' =>'alphaNumericCustom','required'=>true,'allowEmpty'=>true,'message'=>'Only Alphabets')),
                            'mobile' => array('numeric' => array('rule' => 'numeric','required' => true,'message' => 'Only numbers allowed'),
                                            'isUnique'=>array('rule' => 'isUnique','allowEmpty'=>true,'message' => 'Mobile already exist! try new one')));
                            

}
?>