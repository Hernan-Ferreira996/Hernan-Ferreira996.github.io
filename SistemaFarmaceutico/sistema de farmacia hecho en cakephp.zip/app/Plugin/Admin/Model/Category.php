<?php
class Category extends AppModel
{
    public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    public $filterArgs = array('keyword' => array('type' => 'like','field'=>'Category.name'));
    public $validate =array('name' => array('alphaNumeric'=>array('rule' =>'alphaNumericCustom','required'=>true,'allowEmpty'=>false,'message'=>'Only Alphabets'),
                                            'isUnique'=>array('rule' => 'isUnique','allowEmpty'=>true,'message' => 'Category already exist! try new one')));
                            

}
?>