<?php
class Backup extends AppModel
{
    public $validationDomain = 'validation';
    public $useTable = false;
}
?>