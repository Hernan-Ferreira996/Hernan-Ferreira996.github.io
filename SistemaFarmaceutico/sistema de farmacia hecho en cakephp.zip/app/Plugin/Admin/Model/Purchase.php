<?php
class Purchase extends AppModel
{
    public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    public $belongsTo=array('Rack','Category','Supplier');
    public $filterArgs = array('keyword' => array('type' => 'like','field'=>'Purchase.name'));
    /*public $validate =array('name' => array('alphaNumeric'=>array('rule' =>'alphaNumericCustom','required'=>true,'allowEmpty'=>false,'message'=>'Only Alphabets')),
                                            );*/
    
     public function beforeValidate($options = array())
     {
      if (!empty($this->data['Purchase']['purchase_date'])) {
      $this->data['Purchase']['purchase_date'] = $this->dateFormatBeforeSave($this->data['Purchase']['purchase_date']);
      }
      if (!empty($this->data['Purchase']['expiry_date'])) {
      $this->data['Purchase']['expiry_date'] = $this->dateFormatBeforeSave($this->data['Purchase']['expiry_date']);
      }
      
      return true;
   } 
                            

}
?>