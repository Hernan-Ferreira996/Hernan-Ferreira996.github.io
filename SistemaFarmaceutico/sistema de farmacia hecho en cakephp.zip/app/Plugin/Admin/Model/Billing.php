<?php
class Billing extends AppModel
{
    public $validationDomain = 'validation';
    public $actsAs = array('search-master.Searchable');
    public $useTable='tempbillings';
    public $belongsTo=array('Product');
    //public $filterArgs = array('keyword' => array('type' => 'like','field'=>'Rack.name'));
    //public $validate =array('name' => array('alphaNumeric'=>array('rule' =>'alphaNumericCustom','required'=>true,'allowEmpty'=>false,'message'=>'Only Alphabets'),
                                           // 'isUnique'=>array('rule' => 'isUnique','allowEmpty'=>true,'message' => 'Rack already exist! try new one')));
                            

}
?>