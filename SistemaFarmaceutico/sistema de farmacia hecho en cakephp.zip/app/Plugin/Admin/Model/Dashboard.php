<?php
class Dashboard extends AppModel
{
   public $validationDomain = 'validation';
}
