<?php
class Returnproduct extends AppModel
{
    public $validationDomain = 'validation';
    public $useTable='products';
    public $belongsTo=array('Supplier');
    public $actsAs = array('search-master.Searchable');
    public $filterArgs = array('invoice_no' => array('field'=>'invoice_no'),
                               'mobile' => array('field'=>'Supplier.mobile'));
  
                            

}
?>