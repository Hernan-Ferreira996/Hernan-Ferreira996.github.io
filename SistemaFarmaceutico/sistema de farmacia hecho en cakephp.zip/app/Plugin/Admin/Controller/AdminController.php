<?php
class AdminController extends AdminAppController
{
   
}