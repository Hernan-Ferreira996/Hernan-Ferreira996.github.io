<?php
App::uses('CakeTime', 'Utility');
class CashreportsController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Cashreport.id'=>'desc'));
    public function index()
    {
        $cond=array();
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
            
        if(isset($this->params['named']['start_date']) && strlen($this->params['named']['end_date'])>0)
        {
            $cond[]=array('Cashreport.created BETWEEN ? AND ?'=>array(CakeTime::format('Y-m-d',$this->params['named']['start_date']),CakeTime::format('Y-m-d',$this->params['named']['end_date'])));
        }
        $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Cashreport.user_id'=>$userId);
        }
        $this->Paginator->settings['conditions'] = array($this->Cashreport->parseCriteria($this->Prg->parsedParams()),$cond,'Cashreport.finaltotal IS NOT NULL');
        $this->Paginator->settings['fields']=array('DISTINCT Cashreport.bill_num','Cashreport.created','Cashreport.finaltotal');
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
}
?>