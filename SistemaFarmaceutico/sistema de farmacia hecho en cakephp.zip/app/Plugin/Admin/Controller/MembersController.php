<?php
App::uses('SimplePasswordHasher', 'Controller/Component/Auth');
class MembersController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Member.name'=>'asc'));
    public function index()
    { 
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
        $this->Paginator->settings['conditions'] = $this->Member->parseCriteria($this->Prg->parsedParams());
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('Member', $this->Paginator->paginate());
        $at="mwallet";
        $this->set('at',$at);
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
             
        }

    }
    public function add()
    {
        $cusomerId=substr(rand(),0,8);
        $this->set('cusomerId',$cusomerId);
        if(!$this->userPermissionArr['save_right'])
        {
         $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        if ($this->request->is('post'))
        {
            $this->Member->create();
            try
            {
                $this->request->data['Member']['status']='Active';
                if ($this->Member->save($this->request->data))
                {
                    $this->Session->setFlash(__('Customer has been added!'),'flash',array('alert'=>'success'));
                    return $this->redirect(array('action' => 'add'));
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash(__('Invalid Post'),'flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }
    }
    public function edit($id = null)
    {
      if(!$this->userPermissionArr['update_right'])
     {
     $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
     return $this->redirect(array('action' => 'index'));
     }
        if (!$id)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        $ids=explode(",",$id);
        $post=array();
        foreach($ids as $id)
        {
            $post[]=$this->Member->findByid($id);
        }
        $this->set('Member',$post);
        if (!$post)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is(array('post', 'put')))
        {
            try
            {
                if ($this->Member->saveAll($this->request->data))
                {
                    $this->Session->setFlash(__('Customer has been updated!'),'flash',array('alert'=>'success'));
                    return $this->redirect(array('action' => 'index'));
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash(__('Invalid Post.'),'flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
            $this->set('isError',true);
        }
        else
        {
            $this->layout = null;
            $this->set('isError',false);
        }
        if (!$this->request->data)
        {
            $this->request->data = $post;
        }
    }
    public function view($id = null)
    {
     $this->layout = null;
        if (!$id) {
            throw new NotFoundException(__('Invalid post'));
        }

        $post = $this->Member->findById($id);
        if (!$post) {
            throw new NotFoundException(__('Invalid post'));
        }
       
        $this->set('post', $post);
        
    }
    public function mwallet($id=null)
    {
        $this->layout = null;
        $this->set('isError',false);
        if (!$id)
        throw new NotFoundException(__('Invalid post'));
        $post = $this->Member->findById($id);
        if(!$post)
        throw new NotFoundException(__('Invalid post'));
        $this->set('post',$post);
        $this->set('id',$id);
        $this->set('balance',$this->CustomFunction->mwalletBalance($id));
        if ($this->request->is(array('post', 'put')))
        {
            try
            {
                $type=$this->request->data['Member']['action'];
                $amount=$this->request->data['Member']['amount'];
                $remarks=$this->request->data['Member']['remarks'];
                if($this->CustomFunction->mwalletInsert($id,$amount,$type,$remarks))
                {
                    $this->Session->setFlash('E-Wallet has been updated','flash',array('alert'=>'success'));
                    return $this->redirect(array('action' => 'index'));
                }
                else
                {
                    $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
                    return $this->redirect(array('action' => 'index'));
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash('Invalid Post.','flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }
    }
}
?>