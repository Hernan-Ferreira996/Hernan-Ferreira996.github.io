<?php
class ReturnmedicinesController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg','CustomFunction');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Returnmedicine.id'=>'desc'));
    public function index()
    {
        $cond=array('quantity >'=>0);
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
         $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond[]=array('Returnmedicine.user_id'=>$userId);
        }
        $this->Paginator->settings['conditions'] = array($this->Returnmedicine->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
    public function deleteall()
    {
        $this->loadModel('Finalbilling');
        $this->loadModel('Managereturnmedicine');
        $this->loadModel('Product');
     if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            //pr($this->request->data);die();
            if ($this->request->is('post'))
            {
                if(isset($this->request->data['selectAll']) && strlen($this->request->data['selectAll'])>0)
                {
                  unset($this->request->data['selectAll']);  
                }
               
                 
                //pr($this->data);die();
                foreach($this->data as $key => $value)
                {
                    if($value['Returnmedicine']['id']!=0){
                        $finalBilling=$this->Finalbilling->findById($value['Returnmedicine']['id']);
                        $sql='update finalbillings set quantity  =  quantity - '.$value['Returnmedicine']['quantity'].' where id='.$value['Returnmedicine']['id'];
                      
                      //$this->Finalbilling->query('update finalbillings set quantity  =  quantity - $value[Returnmedicine][quantity],total= total - $value[Returnmedicine][total] where id=$value[Returnmedicine][id]');    
                    $this->Finalbilling->query($sql);    
                    $finalBilling=$this->Finalbilling->findById($value['Returnmedicine']['id']);
                    $sql1='update products set qty  =  qty + '.$value['Returnmedicine']['quantity'].' where id='.$finalBilling['Finalbilling']['product_id'];
                      
                    $this->Product->query($sql1);    
                    $record=array('product_id'=>$finalBilling['Finalbilling']['product_id'],'user_id'=>$this->adminValue['User']['id'],'total'=>$value['Returnmedicine']['total'],'price'=>$value['Returnmedicine']['price'],'quantity'=>$value['Returnmedicine']['quantity'],'bill_num'=>$finalBilling['Finalbilling']['bill_num'],'doctor_name'=>$finalBilling['Finalbilling']['doctor_name'],'customer_name'=>$finalBilling['Finalbilling']['customer_name'],'customer_phone'=>$finalBilling['Finalbilling']['customer_phone'],'medicine_name'=>$finalBilling['Finalbilling']['medicine_name']);
                    //pr($record);die();
                    $this->Managereturnmedicine->create();
                    $this->Managereturnmedicine->save($record);
                        if(isset($finalBilling['Finalbilling']['cashback_percentage'])){
                        $amount=($value['Returnmedicine']['total'] * $this->customerCashbackPercentage)/100;
                        $remarks="Amount $amount Deducted from your wallet for return medicine";
                        $memberId=$finalBilling['Finalbilling']['member_id'];
                        $this->CustomFunction->mwalletInsert($memberId,round($amount),"DR",$remarks);
                        }
                    }
                }
                $this->Session->setFlash(__('Return Medicine Successfully !'),'flash',array('alert'=>'success'));
            }        
           $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
}
?>