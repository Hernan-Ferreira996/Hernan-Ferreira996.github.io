<?php
class SuppliersController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Supplier.name'=>'asc'));
    public function index()
    {
        $cond=array();
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
         $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Supplier.user_id'=>$userId);
        }
        $this->Paginator->settings['conditions'] = array($this->Supplier->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
    public function add()
    {
        if(!$this->userPermissionArr['save_right'])
        {
         $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        if ($this->request->is('post'))
        {
            $this->Supplier->create();
            try
            {
                $this->request->data['Supplier']['user_id']=$this->adminValue['User']['id'];
                if ($this->Supplier->save($this->request->data))
                {
                    $this->Session->setFlash(__('Supplier has been added!'),'flash',array('alert'=>'success'));
                    return $this->redirect(array('action' => 'add'));
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash(__('Invalid Post'),'flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
        }
    }
    public function edit($id = null)
    {
      if(!$this->userPermissionArr['update_right'])
     {
     $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
     return $this->redirect(array('action' => 'index'));
     }
        if (!$id)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        $ids=explode(",",$id);
        $post=array();
        foreach($ids as $id)
        {
            $post[]=$this->Supplier->findByid($id);
        }
        $this->set('Supplier',$post);
        if (!$post)
        {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is(array('post', 'put')))
        {
            try
            {
                if ($this->Supplier->saveAll($this->request->data))
                {
                    $this->Session->setFlash(__('Supplier has been updated!'),'flash',array('alert'=>'success'));
                    return $this->redirect(array('action' => 'index'));
                }
            }
            catch (Exception $e)
            {
                $this->Session->setFlash(__('Invalid Post.'),'flash',array('alert'=>'danger'));
                return $this->redirect(array('action' => 'index'));
            }
            $this->set('isError',true);
        }
        else
        {
            $this->layout = null;
            $this->set('isError',false);
        }
        if (!$this->request->data)
        {
            $this->request->data = $post;
        }
    }    
    public function deleteall()
    {
     if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            if ($this->request->is('post'))
            {
                foreach($this->data['Supplier']['id'] as $key => $value)
                {
                    $this->Supplier->delete($value);
                }
                $this->Session->setFlash(__('Supplier has been deleted!'),'flash',array('alert'=>'danger'));
            }        
            $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }
}
?>