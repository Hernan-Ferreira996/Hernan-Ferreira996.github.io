<?php
class SupplierreportsController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg','PhpExcel.PhpExcel');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('Supplierreport.name'=>'asc'));
    public function index()
    {
        $cond=array();
        $currentDate=date('Y-m-d');
	$currentDay=date('d');
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
        $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Supplierreport.user_id'=>$userId);
        }
        $this->Paginator->settings['conditions'] = array($this->Supplierreport->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('posts', $this->Paginator->paginate());
        
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
        }

    }
    /*
    public function deleteall()
    {
     if(!$this->userPermissionArr['delete_right'])
         {
        $this->Session->setFlash(__('No Permission'),'flash',array('alert'=>'danger'));
         return $this->redirect(array('action' => 'index'));
        }
        try
        {
            if ($this->request->is('post'))
            {
                foreach($this->data['Supplierreport']['id'] as $key => $value)
                {
                    $this->Supplierreport->delete($value);
                }
                $this->Session->setFlash(__('Supplier report has been deleted!'),'flash',array('alert'=>'danger'));
            }        
            $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash(__('Please delete related record first.'),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }*/
    
    public function export()
    {
	$this->layout=null;
        $this->autoRender=false;
        try
        {
            $data=$this->exportData();
            $this->PhpExcel->createWorksheet();
            $this->PhpExcel->addTableRow($data);
            $this->PhpExcel->output('Supplierreport',$this->siteName,'Supplierreport.xls','Excel2007');
        }
        catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage(),'flash',array('alert'=>'danger'));
            return $this->redirect(array('action' => 'index'));
        }
    }    
    private function exportData()
    {
	$cond=array();
        $siteName=$this->siteOrganization;
	$userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Supplierreport.user_id'=>$userId);
        }
        $post=$this->Supplierreport->find('all',array('conditions'=>$cond));
        $data=$this->showProductData($post);
        return $data;
    }
    
    private function showProductData($post)
    {
        
        $showData=array();
        if($post)
        {
       
            $showData=array(array(__('Invoice No'),__('Batch No'),__('Rack'),__('Category'),__('Medicine Name'),__('Packet * Quantity'),__('Quantity'),__('Remaining Quantity'),__('Price'),__('Discount (%)'),__('Tax (%)'),__('Net Price'),__('Price Per Piece'),__('Supplier Name'),__('Supplier Mobile'),__('Supplier Store Name'),__('Expiry Date'),__('Purchase Date')));
            
            foreach($post as $rank=>$value)
            {
                   if($value['Supplierreport']['expiry_date']){$expiryDate=CakeTime::format('d-M-Y',$value['Supplierreport']['expiry_date']);}else{$expiryDate=null;}
                   if($value['Supplierreport']['purchase_date']){$puchaseDate=CakeTime::format('d-M-Y',$value['Supplierreport']['purchase_date']);}else{$puchaseDate=null;}
                   $showData[]=array('Invoice No'=>$value['Supplierreport']['invoice_no'],'Batch No'=>$value['Supplierreport']['batch_no'],'Rack'=>$value['Rack']['name'],'Category'=>$value['Category']['name'],
                                  'Medicine Name'=>$value['Supplierreport']['name'],'Packet * Quantity'=>$value['Supplierreport']['packet'].'*'.$value['Supplierreport']['quantity_piece'],'Quantity'=>$value['Supplierreport']['packet']*$value['Supplierreport']['quantity_piece'],
                                  'Remaining Quantity'=>$value['Supplierreport']['qty'],'Price'=>$value['Supplierreport']['onlyprice'],'Discount (%)'=>$value['Supplierreport']['discount'],'Tax (%)'=>$value['Supplierreport']['tax'],
                                  'Net Price'=>$value['Supplierreport']['price'], 'Price Per Piece'=>$value['Supplierreport']['price_one_piece'],'Supplier Name'=>$value['Supplier']['name'],'Supplier Mobile'=>$value['Supplier']['mobile'],
                                  'Supplier Store Name'=>$value['Supplier']['store_name'],'Expiry Date'=>$expiryDate,'Purchase Date'=>$puchaseDate);
            }
            
        }
        else
        {
          $showData=array(array(__('No Record Found')));
         
        }
        return$showData;
    }
    public function download()
    {
        $this->viewClass = 'Media';
        $params = array(
            'id'        => 'sample-Product.xls',
            'name'      => 'SampleProduct',
            'download'  => true,
            'extension' => 'xls',
            'mimeType'  => array('xls' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
            'path'      => APP . 'tmp' . DS.'download'.DS
        );
        $this->set($params);
    }
}
?>