<?php
class MwalletHistoriesController extends AdminAppController {
    public $helpers = array('Html', 'Form','Session','Paginator','Js'=> array('Jquery'));
    public $components = array('Session','Paginator','search-master.Prg');
    public $presetVars = true;
    var $paginate = array('page'=>1,'order'=>array('MwalletHistory.id'=>'desc'));
    public function index($id=null)
    {
        $mWallet=null;
        $this->Prg->commonProcess();
        $this->Paginator->settings = $this->paginate;
        $cond="";$cond1="";
        if($id)
        {
            $cond=" 1=1 AND `MwalletHistory.member_id`=$id ";
            $cond1=" 1=1 AND `Mwallet.member_id`=$id ";
        }
        $this->Paginator->settings['conditions'] = array($this->MwalletHistory->parseCriteria($this->Prg->parsedParams()),$cond);
        $this->Paginator->settings['limit']=$this->pageLimit;
        $this->Paginator->settings['maxLimit']=$this->maxLimit;
        $this->set('record', $this->Paginator->paginate());
        $this->set('id',$id);
         $this->loadModel('Mwallet');
        if(strlen($id)>0)
        {
            $mWallet=$this->Mwallet->find('first',array('joins'=>array(array('table'=>'members','alias'=>'Member','type'=>'INNER','conditions'=>array('Mwallet.member_id=Member.id'))),
                                                                    'conditions'=>$cond1));
            $this->set('mWallet',$mWallet);
        }
        else
        {
            $this->Mwallet->virtualFields=array('credit'=>'SUM(credit)','debit'=>'SUM(debit)','balance'=>'SUM(balance)');
            $mWallet=$this->Mwallet->find('first',array('joins'=>array(array('table'=>'members','alias'=>'Member','type'=>'INNER','conditions'=>array('Mwallet.member_id=Member.id'))),
                                                                    'conditions'=>$cond1));
            $this->set('mWallet',$mWallet);
        }
        if ($this->request->is('ajax'))
        {
            $this->render('index','ajax'); // View, Layout
             
        }

    }
    
}
?>