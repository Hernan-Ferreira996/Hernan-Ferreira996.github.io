<?php
App::uses('CakeTime', 'Utility');
class PurchasereturnreportsController extends AdminAppController
{
    public $components = array('HighCharts.HighCharts');
    public function index()
    {
        $cond=array();$cond1=array();$date="";$dateBetween=false;
        $userId=$this->adminValue['User']['id'];
        if($userId!=1){
        $cond=array('Purchasereturnreport.user_id'=>$userId);
        }
        if ($this->request->is('post'))
        {
            if($this->request->data['Purchasereturnreport']['date'])
            {
                $date=$this->request->data['Purchasereturnreport']['date']['year'];
            }
            if($this->request->data['Purchasereturnreport']['start_date'] && $this->request->data['Purchasereturnreport']['end_date'])
            {
                $cond[]=array('Purchasereturnreport.created BETWEEN ? AND ?'=>array(CakeTime::format('Y-m-d',$this->request->data['Purchasereturnreport']['start_date']),CakeTime::format('Y-m-d',$this->request->data['Purchasereturnreport']['end_date'])));
                $dateBetween=true;
            }
        }
        for ($i = 0; $i < 12; ++$i)
        {
            if(strlen($date)>0)
            {
                $year=$date;
                $searchDate=$year.'-'.(12-$i).'-01';
                $month=CakeTime::format('m',$searchDate);                
                $monthName=CakeTime::format('M Y',$searchDate);
            }
            else
            {
                $year=CakeTime::format("-$i months",'%Y',$this->siteTimezone);
                $month=CakeTime::format("-$i months",'%m',$this->siteTimezone);
                $monthName=CakeTime::format("-$i months",'%B %Y',$this->siteTimezone);
            }
            $salesCount=$this->Purchasereturnreport->find('count',array('conditions'=>array('MONTH(Purchasereturnreport.created)'=>$month,'YEAR(Purchasereturnreport.created)'=>$year,$cond)));
            $earningArr=$this->Purchasereturnreport->find('all',array('fields'=>array('SUM(Purchasereturnreport.price) AS earning'),
                                                             'conditions'=>array('MONTH(Purchasereturnreport.created)'=>$month,'YEAR(Purchasereturnreport.created)'=>$year,$cond)));
            
            
            if($earningArr[0][0]['earning']==null)
            $earning=0;
            else
            $earning=$earningArr[0][0]['earning'];
            $graphMonth[]=$monthName;
            $months[]['MonthArr'] = array('monthName'=>$monthName,'salesCount'=>$salesCount,'earning'=>$earning);
            $performanceChartData[]=(float) $earning;
        }
        $graphMonth=array_reverse($graphMonth);
        $months=array_reverse($months);
        $currMonth=CakeTime::format('m',$this->siteTimezone);
        $currYear=CakeTime::format('Y',$this->siteTimezone);
        
        $totalSalesCount=$this->Purchasereturnreport->find('count',array('conditions'=>$cond));
        $earningArr=$this->Purchasereturnreport->find('all',array('fields'=>array('SUM(Purchasereturnreport.price) AS earning'),
                                                         'conditions'=>$cond));
        $earningArr1=$this->Purchasereturnreport->find('all',array('fields'=>array('SUM(Purchasereturnreport.price) AS earning'),
                                                           'conditions'=>array('MONTH(Purchasereturnreport.created)'=>$currMonth,'YEAR(Purchasereturnreport.created)'=>$currYear,$cond)));
        $monthSalesCount=$this->Purchasereturnreport->find('count',array('conditions'=>array('MONTH(Purchasereturnreport.created)'=>$currMonth,'YEAR(Purchasereturnreport.created)'=>$currYear,$cond)));
        
        
        
        
        
        if($earningArr[0][0]['earning']==null)
        $totalEearning=0;
        else
        $totalEearning=$earningArr[0][0]['earning'];
        if($earningArr1[0][0]['earning']==null)
        $earningMonth=0;
        else
        $earningMonth=$earningArr1[0][0]['earning'];
        $tooltipFormatFunction ="function() { return '<b>'+ this.series.name +'</b><br/>'+ this.x +': '+''+ this.y ;}";
        $chartName = "My Chartdl";
        $mychart = $this->HighCharts->create($chartName,'line');
        $this->HighCharts->setChartParams(
                                          $chartName,
                                          array(
                                                'renderTo'=> "mywrapperdl",  // div to display chart inside
                                                'title'=>__('Purchase Return Report'),
                                                'titleAlign'=> 'center',
                                                'creditsEnabled'=> FALSE,
                                                'xAxisLabelsEnabled'=> TRUE,
                                                'xAxisCategories'=> $graphMonth,
                                                'yAxisTitleText'=> '',
                                                'tooltipEnabled'=> TRUE,
                                                'tooltipFormatter'=> $tooltipFormatFunction,
                                                'enableAutoStep'=> FALSE,
                                                'plotOptionsShowInLegend'=> TRUE,                                              
                                                )
                                          );
        $series = $this->HighCharts->addChartSeries();
        $series->addName(__('Purchase Return Report'))->addData(array_reverse($performanceChartData));
        $mychart->addSeries($series);
        $this->set('totalSalesCount',$totalSalesCount);
        $this->set('totalEearning',$totalEearning);
        $this->set('earningMonth',$earningMonth);
        $this->set('monthSalesCount',$monthSalesCount);
        $this->set('salesReport',$months);
        
        $this->set('dateBetween',$dateBetween);
    }
    
}