<?php
		class DATABASE_CONFIG {
		public $default = array(
			'datasource' => 'Database/Mysql',
			'persistent' => false,
			'host' => 'localhost',
			'login' => 'root',
			'password' => '',
			'database' => 'vardancarecenter',
			'prefix' => '',
			'encoding' => 'utf8',
		);	
		}
		?>