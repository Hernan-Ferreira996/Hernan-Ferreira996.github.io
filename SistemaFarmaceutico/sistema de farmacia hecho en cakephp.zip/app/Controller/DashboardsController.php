<?php
App::uses('CakeTime', 'Utility');
App::uses('CakeNumber', 'Utility');
class DashboardsController extends AppController
{
    public function beforeFilter()
    {
        parent::beforeFilter();
        $this->authenticate();
        $this->userId=$this->userValue['User']['id'];
    }
    public function index()
    {
        $date=$this->currentDate;$checkIn=null;
        // Start update attendance        
        $this->loadModel('Employee');
        $this->loadModel('Application');
        $this->loadModel('Attendance');
         
        $lastAttendanceArr=$this->Attendance->find('first',array('conditions'=>array('Attendance.date !='=>$date,'Attendance.at_status'=>0)));
        if($lastAttendanceArr){
           $lastAttendanceDate=$lastAttendanceArr['Attendance']['date'];
           $employeeAll=$this->Employee->find('all',array('conditions'=>array('Employee.status'=>1)));
             
            
            foreach($employeeAll as $empValue)
            {
                
                $applicationCount=$this->Application->find('count',array('conditions'=>array('Application.leave_date'=>$lastAttendanceDate,'Application.employee_id'=>$empValue['Employee']['id'],'Application.status'=>'Approved')));
                  
               if($applicationCount==0)
               {
               
                    $AttendanceCount=$this->Attendance->find('count',array('conditions'=>array('Attendance.date'=>$lastAttendanceDate,'Attendance.employee_id'=>$empValue['Employee']['id'])));
                   
                    if($AttendanceCount==0)
                    {
                       $this->Attendance->create();
                       $this->Attendance->save(array('employee_id'=>$empValue['Employee']['id'],'date'=>$lastAttendanceDate,'status'=>0,'at_status'=>1)); 
                    }
               }  
        
            }
           $this->Attendance->updateAll(array('at_status'=>1),array('at_status'=>0));
            
        }        
        
        
        
        $this->set('post',$this->Dashboard->findById($this->userId));
       
        $checkIn=$this->Attendance->find('count',array('conditions'=>array('employee_id'=>$this->userId,'check_in'=>null,'date'=>$date,'at_status'=>0)));
        $checkIn1=$this->Attendance->find('count',array('conditions'=>array('employee_id'=>$this->userId,'date'=>$date)));
        $checkOut=$this->Attendance->find('count',array('conditions'=>array('employee_id'=>$this->userId,'check_out'=>null,'date'=>$date,'at_status'=>0)));
        if($checkIn || !$checkIn1){
            $this->set('checkInStatus',true);
        }
        else{
            $this->set('checkInStatus',false);
        }
        $this->set('checkIn',$checkIn);
        $this->set('checkOut',$checkOut);
        $this->loadModel('Award');
        $this->loadModel('Application');
        $this->loadModel('Leavetype');
        $this->loadModel('Application');
        
        $id=$this->userId;
        
       
        
        $yearValue=explode("-",$date);
        $this->set('yearDate',$yearValue[0]);
       
        $currentDay=CakeTime::format('d',$this->currentDate);
        $currentYear=CakeTime::format('Y',$this->currentDate);
        $currentMonth=CakeTime::format('m',$this->currentDate);
        
        $month=$currentMonth;
        $year=$currentYear;
       
        $calender=$this->Attendance->find('all',array('fields'=>array('Emp.*','Attendance.*','Leavetype.*'),
                                                      'joins'=>array(array('table'=>'employees','type'=>'LEFT','alias'=>'Emp','conditions'=>array('Emp.id=Attendance.employee_id')),
                                                                     array('table'=>'leavetypes','type'=>'LEFT','alias'=>'Leavetype','conditions'=>array('Leavetype.id=Attendance.leavetype_id'))),
                                                      'conditions'=>array('Attendance.employee_id'=>$id,'Attendance.status'=>'0'),
                                          ));
        
        $this->set('calender',$calender);
        
        
        $leave=$this->Application->find('all',array('fields'=>array('Application.*','Leavetype.name'),
                                                      'joins'=>array(array('table'=>'leavetypes','type'=>'LEFT','alias'=>'Leavetype','conditions'=>array('Leavetype.id=Application.leavetype_id'))),
                                                      'conditions'=>array('Application.employee_id'=>$id,'Application.status'=>'Approved'),
                                          ));
        
        $this->set('leave',$leave);
        
        
        $this->loadModel('Holiday');
        $holiday=$this->Holiday->find('all',array('conditions'=>array('YEAR(Holiday.date)'=>$currentYear)));
        $this->set('holiday',$holiday);
        
        
        $present=$this->Attendance->find('all',array('fields'=>array('Emp.*','Attendance.*'),
                                                      'joins'=>array(array('table'=>'employees','type'=>'LEFT','alias'=>'Emp','conditions'=>array('Emp.id=Attendance.employee_id'))),
                                                      'conditions'=>array('Attendance.employee_id'=>$id,'Attendance.status'=>'1'),
                                          ));
        $this->set('present',$present);
        $this->set('currentYear',$currentYear);
        
        
        $totalAttendance=$this->Attendance->find('count',array('conditions'=>array('YEAR(Attendance.date)'=>$year,'MONTH(Attendance.date)'=>$month),
                                                               'group'=>'Attendance.date'));
        $totalEmployeeAttendance=$this->Attendance->find('count',array('conditions'=>array('Attendance.status'=>'1','Attendance.employee_id'=>$id,'YEAR(Attendance.date)'=>$year,'MONTH(Attendance.date)'=>$month)));
        $this->set('totalAttendance',$totalAttendance);
        $this->set('totalEmployeeAttendance',$totalEmployeeAttendance);
        
        
        $awardCount=$this->Award->find('count',array('conditions'=>array('Award.employee_id'=>$id)));
        $this->set('awardCount',$awardCount);
        
        $allLeaveTypeCount=$this->Leavetype->find('count');
        $this->set('allLeaveTypeCount',$allLeaveTypeCount);
        
        $empLeaveCount=$this->Application->find('count',array('conditions'=>array('YEAR(Application.created)'=>$currentYear,'Application.status'=>'Approved','Application.employee_id'=>$id)));
        $this->set('empLeaveCount',$empLeaveCount);
        
        $awardRecord=$this->Award->find('all',array('fields'=>array('Employee.*','Award.*'),
                                                    'joins'=>array(array('table'=>'employees','type'=>'LEFT','alias'=>'Employee','conditions'=>array('Employee.id=Award.employee_id'))),
                                                    'conditions'=>array('YEAR(Award.date)'=>$currentYear)));
        $this->set('awardRecord',$awardRecord);
        
         $allHoliday=$this->Holiday->find('all',array('conditions'=>array('MONTH(Holiday.date) >='=>$currentMonth,'DAY(Holiday.date) >='=>$currentDay),
                                                    'order'=>array('MONTH(Holiday.date)'=>'asc',
                                                                   'DAY(Holiday.date)'=>'asc'),
                                                 ));
       
        $this->set('allHoliday',$allHoliday);
        
        $birtdayArr=$this->Employee->find('all',array('conditions'=>array('MONTH(Employee.dob) >='=>$currentMonth,'DAY(Employee.dob) >='=>$currentDay),
                                                    'order'=>array('MONTH(Employee.dob)'=>'asc',
                                                                   'DAY(Employee.dob)'=>'asc'),
                                                 ));
        
        $this->set('birtdayArr',$birtdayArr);
        
        
    }
    public function checkin()
    {
        try{
             $date=$this->currentDate;
            $currentTime=CakeTime::format('H:i:s',CakeTime::convert(time(),$this->siteTimezone));
            $record=array();
             $this->loadModel('Attendance');
             $check=$this->Attendance->find('count',array('conditions'=>array('employee_id'=>$this->userId,'status'=>1,'date'=>$date,'check_in <>'=>NULL)));
             if($check==0)
             {
             $record=array('employee_id'=>$this->userId,'status'=>1,'date'=>$date,'check_in'=>$currentTime);
             $this->Attendance->save($record);
             }
             return $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage,'flash',array('alert'=>'danger'));
        }
    }
    public function checkout()
    {
        try{
             $date=$this->currentDate;
            $currentTime=CakeTime::format('H:i:s',CakeTime::convert(time(),$this->siteTimezone));
            $record=array();
            $this->loadModel('Attendance');
            $check=$this->Attendance->find('count',array('conditions'=>array('employee_id'=>$this->userId,'status'=>1,'date'=>$date,'check_out <>'=>NULL)));
            if($check==0)
            {
                $attendance= $this->Attendance->find('first',array('conditions'=>array('employee_id'=>$this->userId,'date'=>$date)));
                $id=$attendance['Attendance']['id'];
                $record=array('id'=>$id,'employee_id'=>$this->userId,'status'=>1,'date'=>$date,'check_out'=>$currentTime);
                $this->Attendance->save($record);
            }
             return $this->redirect(array('action' => 'index'));
        }
        catch (Exception $e)
        {
            $this->Session->setFlash($e->getMessage,'flash',array('alert'=>'danger'));
        }
    }
}