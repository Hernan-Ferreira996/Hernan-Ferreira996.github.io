<?php
class AdminsectionsController extends AppController
{
    public function index()
    {
        $this->Redirect('../admin/');
        exit;
    }
}
?>
